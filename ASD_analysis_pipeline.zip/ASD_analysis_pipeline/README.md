# ASD Immune–Synaptic Dichotomy — Reproducible Analysis Pipeline

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.20715220.svg)](https://doi.org/10.5281/zenodo.20715220)

> **Manuscript**: Immune–synaptic transcriptomic dichotomy in autism spectrum disorder peripheral blood, with birth-associated innate immune activation: an integrative multi-dataset study

---

## Overview

This repository contains the complete, self-contained R pipeline for reproducing all analyses described in the manuscript. The pipeline integrates five GEO transcriptomic datasets (n=517) and three external validation cohorts to characterize reproducible ASD peripheral blood molecular subtypes, assess cross-platform reproducibility via a platform-conditioned permutation test, evaluate genetic support through tissue-stratified Mendelian randomization with colocalization, and map candidate drugs.

All code uses **relative paths and auto-detection** — no hardcoded absolute paths. Clone this repository, install dependencies, and run.

---

## Repository Structure

```
├── README.md                     # This file
├── R/                            # Analysis scripts (11 modules)
│   ├── 00_run_all.R              # Master orchestrator
│   ├── 01_data_integration.R     # GEO download, preprocessing, ComBat
│   ├── 02_brain_deg.R            # Differential expression + permutation test
│   ├── 03_eqtl_stratification.R  # GTEx tissue-stratified eQTL classification
│   ├── 04_mr_coloc.R             # Mendelian randomization + colocalization
│   ├── 05_drug_repurposing.R     # Drug-target mapping (DrugBank/CTD/SFARI)
│   ├── 06_consensus_clustering.R # ConsensusClusterPlus molecular subtyping
│   ├── 07_immune_deconvolution.R # ssGSEA + LM22 immune deconvolution
│   ├── 08_predictive_model.R     # Random forest cross-stage prediction
│   ├── module3_adv_coloc.R       # Advanced coloc (H3/LD sensitivity)
│   └── generate_final_figures.R  # Publication-quality figure generation
├── data/                          # Place GEO raw data here after download
├── output/                        # All intermediate + final output
│   ├── module1_results.rds        # Unified expression matrix (4890 genes × 517 samples)
│   ├── module2_results.rds        # DEG results + permutation null distributions
│   ├── module4_results.rds        # Consensus clustering subtype assignments
│   ├── module5_results.rds        # LODO cross-validation results
│   ├── module10_results.rds       # GTEx eQTL tissue classification
│   ├── single_dataset_immune_results.rds  # ssGSEA deconvolution per dataset
│   ├── coloc_per_snp_results.csv          # Per-gene coloc posterior probabilities
│   ├── drug_repurposing_candidates.csv     # 32 candidate compounds
│   ├── asd_subtype_labels.csv              # Sample-level subtype assignments
│   └── non_cord_immune_deconv_stats.csv   # Non-cord blood deconvolution stats
└── figures/                       # All main + supplementary figures
```

---

## System Requirements

- **R** ≥ 4.0
- **R packages** (auto-installed by `00_run_all.R`):
  - Bioconductor: `limma`, `sva`, `org.Hs.eg.db`, `AnnotationDbi`, `GEOquery`, `ConsensusClusterPlus`, `GSVA`, `coloc`, `edgeR`
  - CRAN: `ggplot2`, `data.table`, `dplyr`, `reshape2`, `pheatmap`, `randomForest`, `glmnet`, `pROC`, `gridExtra`, `TwoSampleMR`, `ieugwasr`, `MendelianRandomization`
- **Disk space**: ~2 GB for raw GEO downloads + intermediate files
- Internet connection required for GEO data download (Module 1)

---

## Data Sources

All primary data are publicly available from GEO:

| Dataset | Tissue | n | Platform | Module(s) |
|---------|--------|---|----------|-----------|
| [GSE148450](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE148450) | Maternal blood | 159 | GPL25483 | 1, 4, 6, 7, 8 |
| [GSE123302](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE123302) | Cord blood | 144 | GPL16686 | 1, 4, 6, 7, 8 |
| [GSE18123](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE18123) | Childhood blood | 99 | GPL570 | 1, 4, 6, 7, 8 |
| [GSE38322](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE38322) | Postmortem brain (BA9) | 36 | GPL10558 | 1, 2, 3 |
| [GSE28521](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE28521) | Postmortem brain (multi-region) | 79 | GPL6883 | 1, 2, 3 |

**External validation** (supplementary):

| Dataset | Specimen | n | Platform |
|---------|----------|---|----------|
| [GSE26415](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE26415) | Peripheral blood leukocytes | 21 | Agilent 44K |
| [GSE15402](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE15402) | LCL (lymphoblastoid) | 116 | TIGR 40K |
| [GSE140702](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE140702) | CD14+ monocytes | 130 | Illumina HiSeq 4000 |

**External databases** (for orthogonal validation):

| Resource | Purpose | Module |
|----------|---------|--------|
| [gnomAD v4](https://gnomad.broadinstitute.org) | LoF/missense constraint (pLI) | Supplementary |
| [GTEx v8](https://gtexportal.org) | Multi-tissue eQTL NES | 3, 4 |
| [eQTLGen](https://www.eqtlgen.org) | cis-eQTL instruments (N=31,684) | 4 |
| [PGC ASD GWAS](https://pgc.unc.edu) | ASD summary statistics (ieu-a-1185) | 4 |
| [DrugBank](https://go.drugbank.com) / [CTD](http://ctdbase.org) / [SFARI Gene](https://gene.sfari.org) | Drug-target mapping | 5 |

---

## Quick Start

1. **Clone or download** this repository.

2. **Install R dependencies** (one-time):
   ```r
   # In R console, run:
   source("R/00_run_all.R")
   # This will auto-install missing packages, then execute the full pipeline.
   ```

3. **Run the full pipeline**:
   ```bash
   Rscript R/00_run_all.R
   ```
   Expected runtime: ~4–6 hours (mostly GEO downloads + permutation testing).

4. **Run individual modules**:
   Each module can be executed independently after Module 1 has completed:
   ```bash
   Rscript R/01_data_integration.R
   Rscript R/02_brain_deg.R
   Rscript R/06_consensus_clustering.R
   Rscript R/07_immune_deconvolution.R
   # ... etc.
   ```

5. **Generate figures** after all modules:
   ```bash
   Rscript R/generate_final_figures.R
   ```

---

## Module Descriptions

### Module 0 — 00_run_all.R (Orchestrator)
- **Inputs**: None (auto-downloads GEO data)
- **Outputs**: All results in `output/`
- **What it does**: Sequentially executes Modules 1–8, activates the pre-installed Conda environment if available, and validates each module's outputs

### Module 1 — 01_data_integration.R (Data Integration)
- **Inputs**: Raw GEO datasets (auto-downloaded via GEOquery)
- **Outputs**: `module1_results.rds` — 4,890 genes × 517 samples unified matrix
- **Key steps**:
  - Probe-to-gene mapping via platform-native annotations (max-IQR probe per gene)
  - Quantile normalization and low-expression filtering (log2 > 2 in ≥10% samples)
  - ComBat batch correction with diagnosis as protected covariate
  - PCA diagnostics (batch R², diagnosis R², tissue R²)
  - 4 housekeeping gene cross-tissue CV calibration

### Module 2 — 02_brain_deg.R (Brain DEG + Permutation Test)
- **Inputs**: `module1_results.rds`
- **Outputs**: `module2_results.rds` — 81 reproducible DEGs, permutation null distributions
- **Key steps**:
  - limma-trend differential expression within each brain platform
  - Platform-conditioned permutation test: diagnoses shuffled independently per platform
  - Dual-threshold design: 200 strict (FDR<0.05, |logFC|>0.5) + 100 relaxed (P<0.05) permutations
  - 142 high-confidence DEGs (cross-platform confidence scoring)
  - Positive control: 7 housekeeping genes → zero false positives
  - Negative control: 12 tissue-specific markers → all retained (|logFC|>2.0)
  - Statistical power estimation from residual variance structure

### Module 3 — 03_eqtl_stratification.R (GTEx Tissue-Stratified eQTL)
- **Inputs**: `module1_results.rds`, GTEx Portal NES values (curated in Supplementary Table S4)
- **Outputs**: Tissue-specificity classification for 20 prioritized genes
- **Key steps**:
  - Immune Specificity Index: ISI = (WB_NES + EBV_NES) / (WB_NES + EBV_NES + Brain_NES + 0.01)
  - Classification: immune-tissue (ISI>0.70) / brain-tissue (ISI<0.30) / shared
  - Mean blood-to-brain NES ratio: 3.4-fold

### Module 4 — 04_mr_coloc.R (Mendelian Randomization + Colocalization)
- **Inputs**: eQTLGen cis-eQTL, PGC ASD GWAS (ieu-a-1185), GTEx Brain Cortex eQTL
- **Outputs**: 20 nominally significant MR genes, per-gene coloc posterior probabilities
- **Key steps**:
  - Two-sample MR: Wald ratio for blood eQTLGen (N=31,684) instruments
  - Tissue-stratified MR: brain GTEx (N≈200) instruments (exploratory)
  - Per-SNP parametric colocalization (coloc): 22 evaluable genes
  - β-based coloc sensitivity (8 genes under both eQTL contexts)
  - H3 sensitivity controls (GWAS signal at independent locus) and LD decay sensitivity (20/50/100)

### Module 5 — 05_drug_repurposing.R (Drug-Target Mapping)
- **Inputs**: 81 DEGs + 142 high-confidence genes + 20 MR candidates
- **Outputs**: 32 candidate compounds (24 FDA-approved)
- **Key steps**:
  - Mapping against DrugBank, Comparative Toxicogenomics Database (CTD), SFARI Gene
  - Annotated by therapeutic class, SFARI risk gene overlap, and eQTL evidence tier

### Module 6 — 06_consensus_clustering.R (Molecular Subtyping)
- **Inputs**: `module1_results.rds`
- **Outputs**: `module4_results.rds` — ASD-Immune (n=86) vs ASD-Synaptic (n=89) labels
- **Key steps**:
  - 80 candidate genes (brain DEGs ∪ MR candidates, variance-ranked)
  - ConsensusClusterPlus: PAM, 1−Pearson distance, 100 resampling × 80% subsampling
  - Sensitivity: immune gene removal (8 genes, PAC 0.413→0.248, ARI=0.356)

### Module 7 — 07_immune_deconvolution.R (Immune Deconvolution)
- **Inputs**: `module1_results.rds`, `module4_results.rds` (subtype labels)
- **Outputs**: `single_dataset_immune_results.rds` — per-dataset ssGSEA scores
- **Key steps**:
  - ssGSEA + LM22 (12–16/22 cell types evaluable per dataset)
  - Single-dataset analysis (avoids multi-platform gene intersection loss)
  - Sensitivity: literature-curated marker gene mean expression (Bindea 2013; Aran 2017)
  - Non-cord ASD-Immune deconvolution (pooled z-score, FDR=0.045 Treg depletion)

### Module 8 — 08_predictive_model.R (Predictive Modelling)
- **Inputs**: `module1_results.rds`, `module4_results.rds`
- **Outputs**: `module5_results.rds` — LODO AUC, permutation test, feature importance
- **Key steps**:
  - 20-gene Random Forest (2,000 trees, mtry=4)
  - Leave-one-dataset-out (LODO) nested cross-validation
  - Three-stage feature selection (variance filter → LASSO → RF importance) fully within each fold
  - Permutation test: 500 iterations, p=0.034

### Supplementary — module3_adv_coloc.R (Advanced Colocalization)
- H3 sensitivity, LD decay analysis, per-SNP colocalization at full eQTLGen resolution

### Supplementary — generate_final_figures.R (Figure Generation)
- Generates all main (Fig 1–7) and supplementary (Fig S1–S7) figures at 300 DPI
- Includes the redesigned research framework flowchart

---

## Reproducibility

- **Seed**: `set.seed(42)` throughout
- **Platform**: All analyses run on R ≥ 4.0 on macOS/Linux
- **Package versions**: See `session_info.txt` (generated by `00_run_all.R`)
- **Path handling**: All scripts use `normalizePath(dirname(script_path))` auto-detection with fallback traversal to locate the project root by searching for the `03_原始数据` sentinel directory

---

## Citation

If you use this pipeline or data, please cite:

```
[Authors]. Immune–synaptic transcriptomic dichotomy in autism spectrum 
disorder peripheral blood, with birth-associated innate immune activation: 
an integrative multi-dataset study. [Journal]. [Year].
```

---

## License

MIT License. See `LICENSE` file.

---

## Contact

[Corresponding Author Email]
