# ============================================================================
# Module 4 (FIXED): Molecular Subtyping on ALL 175 ASD Blood Samples
# Fixes:
#   1. Uses ALL ASD blood samples from unified matrix (3 datasets combined)
#   2. Shows K=2/3/4 consensus metrics
#   3. Reports silhouette widths and PAC scores
#   4. Subtype labels assigned by immune/synaptic marker expression
# ============================================================================
suppressMessages({
  library(ConsensusClusterPlus)
  library(pheatmap)
  library(ggplot2)
  library(limma)
})

# Auto-detect project root
if (!requireNamespace("rstudioapi", quietly = TRUE)) install.packages("rstudioapi", repos = "https://cloud.r-project.org")
script_path <- tryCatch(rstudioapi::getActiveDocumentContext()$path, error = function(e) "")
if (script_path == "" || is.null(script_path)) {
  args <- commandArgs(trailingOnly = FALSE)
  fa <- grep("^--file=", args, value = TRUE)
  script_path <- if (length(fa) > 0) normalizePath(sub("^--file=", "", fa)) else normalizePath(".")
}
workdir <- normalizePath(dirname(script_path))
for (i in 1:5) {
  if (file.exists(file.path(workdir, "03_原始数据"))) break
  workdir <- dirname(workdir)
}
outdir  <- file.path(workdir, "分析结果")
dir.create(outdir, showWarnings = FALSE, recursive = TRUE)

cat("===== Module 4 (FIXED): ASD Molecular Subtyping (All 175 Blood Samples) =====\n\n")

# ============================================================================
# 1. Load unified expression data
# ============================================================================
cat("1. Loading unified expression matrix...\n")
mod1 <- readRDS(file.path(outdir, "module1_results.rds"))
expr <- mod1$expr; meta <- mod1$meta

# Extract ASD-only blood samples
asd_blood <- meta$Diagnosis == "ASD" & meta$TissueSimple != "Brain"
asd_expr <- expr[, asd_blood, drop = FALSE]
asd_meta <- meta[asd_blood, ]
cat(sprintf("  ASD blood samples: %d\n", ncol(asd_expr)))
cat(sprintf("  Datasets: %s\n", paste(unique(asd_meta$Dataset), collapse=", ")))
cat(sprintf("  Tissue breakdown:\n"))
print(table(asd_meta$TissueSimple))

# ============================================================================
# 2. Select feature genes (combined brain DEG + MR genes)
# ============================================================================
cat("\n2. Selecting feature genes for clustering...\n")
# Use brain high-confidence DEGs + MR causal genes where available
mod2 <- readRDS(file.path(outdir, "module2_results.rds"))
brain_genes <- mod2$high_conf_genes
cat(sprintf("  Brain high-confidence DEGs: %d\n", length(brain_genes)))

mod3 <- readRDS(file.path(outdir, "module3_results.rds"))
mr_genes <- mod3$causal_genes
cat(sprintf("  MR causal genes: %d\n", length(mr_genes)))

# Combined gene set
feature_genes <- unique(c(brain_genes, mr_genes))
feature_genes <- intersect(feature_genes, rownames(asd_expr))
cat(sprintf("  Combined features in expression matrix: %d\n", length(feature_genes)))

# Cap at 100-150 most variable
if (length(feature_genes) > 150) {
  vars <- apply(asd_expr[feature_genes, ], 1, var, na.rm = TRUE)
  feature_genes <- names(sort(vars, decreasing = TRUE))[1:150]
  cat(sprintf("  Capped at 150 most variable features\n"))
}
cat(sprintf("  Final clustering features: %d genes\n", length(feature_genes)))

# ============================================================================
# 3. Consensus Clustering (K=2 to 5)
# ============================================================================
cat("\n3. Running ConsensusClusterPlus (K=2..5)...\n")
clust_data <- asd_expr[feature_genes, ]
clust_scaled <- t(scale(t(clust_data)))

set.seed(42)
old_wd <- getwd()
setwd(outdir)
cc_results <- ConsensusClusterPlus(
  d = as.matrix(clust_scaled),
  maxK = 5,
  reps = 100,
  pItem = 0.8,
  pFeature = 0.8,
  clusterAlg = "pam",
  distance = "pearson",
  seed = 42,
  plot = NULL,
  writeTable = FALSE
)
setwd(old_wd)

# ============================================================================
# 4. Evaluate K selection metrics
# ============================================================================
cat("\n4. Evaluating optimal K...\n")
cat(sprintf("  %-4s %-18s %-18s %-18s\n", "K", "MeanConsensus", "SilhouetteWidth", "PAC_score"))

for (k in 2:5) {
  cm <- cc_results[[k]][["consensusMatrix"]]
  # Mean consensus (within-cluster)
  classes <- cc_results[[k]][["consensusClass"]]
  mean_cons <- mean(sapply(unique(classes), function(cl) {
    idx <- which(classes == cl)
    if (length(idx) > 1) mean(cm[idx, idx][upper.tri(matrix(0, length(idx), length(idx)))])
    else 1
  }))

  # Silhouette width
  dist_mat <- 1 - cor(as.matrix(clust_scaled), method = "pearson")
  sil <- cluster::silhouette(classes, dist_mat)
  mean_sil <- mean(sil[, 3])

  # PAC score (proportion of ambiguous clustering)
  pac <- mean(cm > 0.1 & cm < 0.9)

  cat(sprintf("  %-4d %-18.4f %-18.4f %-18.4f\n", k, mean_cons, mean_sil, pac))
}

# Determine optimal K by consensus
optimal_k <- 2  # default
best_cons <- 0
for (k in 2:5) {
  cm <- cc_results[[k]][["consensusMatrix"]]
  classes <- cc_results[[k]][["consensusClass"]]
  mean_cons <- mean(sapply(unique(classes), function(cl) {
    idx <- which(classes == cl)
    if (length(idx) > 1) mean(cm[idx, idx][upper.tri(matrix(0, length(idx), length(idx)))])
    else 1
  }))
  if (mean_cons > best_cons) { best_cons <- mean_cons; optimal_k <- k }
}
cat(sprintf("\n  Optimal K (by consensus): %d\n", optimal_k))

# ============================================================================
# 5. Extract and annotate subtypes
# ============================================================================
cat("\n5. Extracting subtypes for K=2 and K=3...\n")

subtype_df <- data.frame(
  Sample = colnames(asd_expr),
  Dataset = asd_meta$Dataset,
  Tissue = asd_meta$TissueSimple,
  stringsAsFactors = FALSE
)

for (k in 2:3) {
  classes <- cc_results[[k]][["consensusClass"]]
  subtype_df[[paste0("K", k)]] <- classes[subtype_df$Sample]

  # Annotate with immune/synaptic labels (K=2 only)
  if (k == 2) {
    immune_markers <- intersect(c("IFITM3","CXCL16","HSPB1","ABCA1","JUN","IFITM2","MSN"), feature_genes)
    synaptic_markers <- intersect(c("SYN1","DLG4","SYP","SNAP25","GAP43","STMN2"), feature_genes)

    overall_immune <- mean(colMeans(clust_data[immune_markers, , drop = FALSE], na.rm = TRUE))

    cluster_names <- c()
    for (cl in sort(unique(classes))) {
      samples_cl <- subtype_df$Sample[classes == cl]
      imm_mean <- mean(colMeans(clust_data[immune_markers, samples_cl, drop = FALSE], na.rm = TRUE))
      cluster_names[as.character(cl)] <- ifelse(imm_mean > overall_immune, "ASD-Immune", "ASD-Synaptic")
    }
    subtype_df$SubtypeName <- cluster_names[as.character(classes)]
  }
}

cat("\n  K=2 subtype distribution:\n")
print(table(subtype_df$SubtypeName, subtype_df$Tissue))
cat(sprintf("\n  Overall: %s\n", paste(table(subtype_df$SubtypeName), collapse=", ")))

cat("\n  K=3 subtype distribution:\n")
print(table(subtype_df$K3))

# ============================================================================
# 6. Subtype-specific differential expression
# ============================================================================
cat("\n6. Subtype differential expression analysis...\n")

# Compare ASD-Immune vs ASD-Synaptic
if ("SubtypeName" %in% colnames(subtype_df)) {
  st1_samples <- subtype_df$Sample[subtype_df$SubtypeName == "ASD-Immune"]
  st2_samples <- subtype_df$Sample[subtype_df$SubtypeName == "ASD-Synaptic"]

  if (length(st1_samples) >= 5 && length(st2_samples) >= 5) {
    st_expr <- asd_expr[, c(st1_samples, st2_samples)]
    st_group <- factor(c(rep("Immune", length(st1_samples)), rep("Synaptic", length(st2_samples))))
    st_design <- model.matrix(~ st_group)
    st_fit <- lmFit(st_expr, st_design) |> eBayes(trend = TRUE)
    st_de <- topTable(st_fit, coef = 2, number = Inf, adjust.method = "BH")

    cat(sprintf("  DEGs between subtypes (FDR<0.05): %d\n", sum(st_de$adj.P.Val < 0.05)))
    cat("  Top 10 upregulated in ASD-Immune:\n")
    top_up <- head(st_de[st_de$logFC > 0, ], 10)
    for (i in 1:nrow(top_up)) {
      cat(sprintf("    %-10s logFC=%+.3f adjP=%.4f\n",
                  rownames(top_up)[i], top_up$logFC[i], top_up$adj.P.Val[i]))
    }
  }
}

# ============================================================================
# 7. Dataset composition check
# ============================================================================
cat("\n7. Subtype composition across datasets...\n")
if ("SubtypeName" %in% colnames(subtype_df)) {
  cat("  K=2 subtypes x Dataset:\n")
  print(table(subtype_df$SubtypeName, subtype_df$Dataset))
}

# ============================================================================
# 8. Save
# ============================================================================
cat("\n8. Saving results...\n")
saveRDS(list(
  subtypes = subtype_df,
  consensus_results = cc_results,
  genes_used = feature_genes,
  optimal_k = optimal_k,
  subtype_de = if (exists("st_de")) st_de else NULL
), file.path(outdir, "module4_results.rds"))

write.csv(subtype_df, file.path(outdir, "asd_subtype_labels.csv"), row.names = FALSE)

sink(file.path(outdir, "module4_summary.txt"))
cat(sprintf("Module 4 (FIXED): ASD Subtyping\nDate: %s\n\n", Sys.Date()))
cat(sprintf("Samples: %d ASD blood samples from %s\n",
            ncol(asd_expr), paste(unique(asd_meta$Dataset), collapse=", ")))
cat(sprintf("Features: %d genes (%d brain DEG + %d MR)\n",
            length(feature_genes), length(intersect(brain_genes, feature_genes)),
            length(intersect(mr_genes, feature_genes))))
cat(sprintf("Optimal K: %d\n\n", optimal_k))
cat("=== Subtype Distribution (K=2) ===\n")
if ("SubtypeName" %in% colnames(subtype_df)) print(table(subtype_df$SubtypeName))
cat("\nK=3:\n"); print(table(subtype_df$K3))
cat("\n=== Dataset Composition ===\n")
if ("SubtypeName" %in% colnames(subtype_df)) print(table(subtype_df$SubtypeName, subtype_df$Dataset))
sink()

cat(sprintf("\n===== Module 4 (FIXED) DONE: %d samples subtyped =====\n", ncol(asd_expr)))
