# ============================================================================
# Generate All Updated Figures from Final Results
# ============================================================================
suppressMessages({
  library(ggplot2); library(pheatmap); library(reshape2); library(pROC)
  library(dplyr); library(gridExtra); library(GSVA)
})

# Auto-detect project root
if (!requireNamespace("rstudioapi", quietly = TRUE)) install.packages("rstudioapi", repos = "https://cloud.r-project.org")
script_path <- tryCatch(rstudioapi::getActiveDocumentContext()$path, error = function(e) "")
if (script_path == "" || is.null(script_path)) {
  args <- commandArgs(trailingOnly = FALSE)
  fa <- grep("^--file=", args, value = TRUE)
  script_path <- if (length(fa) > 0) normalizePath(sub("^--file=", "", fa)) else normalizePath(".")
}
workdir <- normalizePath(dirname(script_path))
for (i in 1:5) {
  if (file.exists(file.path(workdir, "03_原始数据"))) break
  workdir <- dirname(workdir)
}
outdir  <- file.path(workdir, "分析结果")
figdir  <- file.path(outdir, "figures")
dir.create(figdir, showWarnings=FALSE, recursive=TRUE)

# Load all data
mod1 <- readRDS(file.path(outdir, "module1_results.rds"))
mod2 <- readRDS(file.path(outdir, "module2_results.rds"))
mod3 <- readRDS(file.path(outdir, "module3_results.rds"))
mod4 <- readRDS(file.path(outdir, "module4_results.rds"))
mod5 <- readRDS(file.path(outdir, "module5_results.rds"))
mod10 <- readRDS(file.path(outdir, "module10_results.rds"))
immune <- readRDS(file.path(outdir, "single_dataset_immune_results.rds"))

meta <- mod1$meta; expr <- mod1$expr; st <- mod4$subtypes
eGene <- mod10$eGene_classification

cat("All data loaded.\n")

theme_pub <- theme_minimal(base_size=11) +
  theme(plot.title=element_text(face="bold", hjust=0.5),
        plot.subtitle=element_text(size=9, hjust=0.5, color="grey40"),
        legend.position="bottom")

# ====================================================================
# Figure 1: Sample Distribution + Confounding Matrix
# ====================================================================
cat("\n--- Figure 1 ---\n")

# Panel A: Barplot
fig1a_data <- as.data.frame(table(meta$Dataset, meta$Diagnosis))
colnames(fig1a_data) <- c("Dataset","Diagnosis","Count")
p1a <- ggplot(fig1a_data, aes(x=Dataset, y=Count, fill=Diagnosis)) +
  geom_bar(stat="identity", position="dodge", alpha=0.85) +
  geom_text(aes(label=Count), position=position_dodge(0.9), vjust=-0.3, size=2.8) +
  scale_fill_manual(values=c("ASD"="#E41A1C","Control"="#377EB8")) +
  labs(title="Sample Distribution Across 5 GEO Datasets (n=517)",
       subtitle=sprintf("402 Blood + 115 Brain | 3 Developmental Stages"),
       x="", y="Samples") + theme_pub +
  theme(axis.text.x=element_text(angle=30, hjust=1))
ggsave(file.path(figdir,"Figure_1_panel_A.png"), p1a, width=9, height=6, dpi=200)

# Panel B: Confounding matrix
conf_data <- as.data.frame(table(meta$Dataset, meta$TissueSimple))
colnames(conf_data) <- c("Dataset","Tissue","Count")
p1b <- ggplot(conf_data, aes(x=Dataset, y=Tissue, fill=Count)) +
  geom_tile(color="white", linewidth=1) +
  geom_text(aes(label=Count), size=4) +
  scale_fill_gradient(low="white", high="#E41A1C") +
  labs(title="Tissue-Platform Confounding Matrix",
       subtitle="Each dataset = unique tissue + unique platform — cross-tissue unverifiable",
       x="Dataset (Platform)", y="Tissue") + theme_pub
ggsave(file.path(figdir,"Figure_1_panel_B.png"), p1b, width=9, height=5, dpi=200)

# Panel C: PCA
pca_sc <- prcomp(t(expr), center=TRUE, scale.=TRUE, rank.=50)$x
pca_var <- summary(prcomp(t(expr), center=TRUE, scale.=TRUE, rank.=50))$importance[2,]*100
p1c <- ggplot(data.frame(PC1=pca_sc[,1], PC2=pca_sc[,2], Tissue=meta$TissueSimple),
              aes(x=PC1, y=PC2, color=Tissue)) +
  geom_point(alpha=0.5, size=1.5) +
  stat_ellipse(level=0.68, linewidth=0.8) +
  scale_color_brewer(palette="Set2") +
  labs(title="PCA After ComBat Correction",
       subtitle=sprintf("PC1=%.1f%%, PC2=%.1f%% | Batch R²=0.005", pca_var[1], pca_var[2]),
       x=sprintf("PC1 (%.1f%%)", pca_var[1]), y=sprintf("PC2 (%.1f%%)", pca_var[2])) + theme_pub
ggsave(file.path(figdir,"Figure_1_panel_C.png"), p1c, width=8, height=6, dpi=200)

# ====================================================================
# Figure 3: Brain DEG Volcano + Permutation Null
# ====================================================================
cat("--- Figure 3 ---\n")
de_obs <- mod2$de_combined
de_obs$Gene <- rownames(de_obs)
de_obs$Significance <- "NS"
de_obs$Significance[de_obs$adj.P.Val<0.05 & abs(de_obs$logFC)>0.5] <- "FDR<0.05 |logFC|>0.5"
de_obs$Significance[de_obs$adj.P.Val<0.01 & abs(de_obs$logFC)>1.0] <- "FDR<0.01 |logFC|>1"
de_obs$negLog10P <- -log10(de_obs$P.Value)
top_genes <- head(de_obs[order(de_obs$P.Value),], 12)

p3a <- ggplot(de_obs, aes(x=logFC, y=negLog10P, color=Significance)) +
  geom_point(alpha=0.4, size=0.8) +
  scale_color_manual(values=c("FDR<0.01 |logFC|>1"="#E41A1C","FDR<0.05 |logFC|>0.5"="#377EB8","NS"="gray70")) +
  geom_hline(yintercept=-log10(0.05), linetype="dashed", color="gray50") +
  geom_vline(xintercept=c(-0.5,0.5), linetype="dotted", color="gray50") +
  ggrepel::geom_text_repel(data=top_genes, aes(label=Gene), size=2.5, max.overlaps=15) +
  labs(title="Brain DEGs: GSE38322 + GSE28521 (n=115)",
       subtitle=sprintf("%d DEGs | %d/%d (%.1f%%) direction-consistent | %d high-confidence",
                        mod2$obs_deg, mod2$direction_consistent, mod2$obs_deg,
                        mod2$direction_consistent/mod2$obs_deg*100, length(mod2$high_conf_genes)),
       x="log2 FC (ASD/Control)", y="-log10(P)") + theme_pub
ggsave(file.path(figdir,"Figure_3_panel_A.png"), p3a, width=10, height=8, dpi=200)

# Panel B: Dual-threshold permutation null
null_df <- rbind(
  data.frame(DEGs=mod2$perm_null_strict, Threshold=sprintf("Strict: Obs=%d, Null=0, p=0.005", mod2$obs_deg)),
  data.frame(DEGs=mod2$perm_null_relaxed, Threshold=sprintf("Relaxed: Obs=%d, Null=%.0f±%.0f, p=0.010",
                                                             mod2$obs_relaxed, mean(mod2$perm_null_relaxed), sd(mod2$perm_null_relaxed)))
)
p3b <- ggplot(null_df, aes(x=DEGs, fill=Threshold)) +
  geom_histogram(bins=30, alpha=0.7) + facet_wrap(~Threshold, scales="free", ncol=1) +
  scale_fill_manual(values=c("#E41A1C","#377EB8")) +
  labs(title="Platform-Conditioned Permutation Test", x="Cross-Platform DEGs", y="Frequency") + theme_pub +
  theme(legend.position="none")
ggsave(file.path(figdir,"Figure_3_panel_B.png"), p3b, width=9, height=7, dpi=200)

# ====================================================================
# Figure 4: Subtype Distribution
# ====================================================================
cat("--- Figure 4 ---\n")
st_counts <- table(st$Subtype)
p4a <- ggplot(as.data.frame(st_counts), aes(x=Var1, y=Freq, fill=Var1)) +
  geom_bar(stat="identity", alpha=0.85, width=0.5) +
  geom_text(aes(label=sprintf("n=%d\n(%.1f%%)", Freq, Freq/sum(Freq)*100)), vjust=-0.1, size=4) +
  scale_fill_manual(values=c("ASD-Immune"="#E41A1C","ASD-Synaptic"="#377EB8")) +
  labs(title="Transcriptomic Partitions (K=2)", subtitle="Consensus clustering of 175 ASD blood samples",
       x="", y="Samples") + theme_pub + ylim(0, max(st_counts)*1.3) + theme(legend.position="none")
ggsave(file.path(figdir,"Figure_4_panel_A.png"), p4a, width=6, height=5, dpi=200)

# Panel B: Dataset composition
comp <- as.data.frame(table(st$Dataset, st$Subtype))
colnames(comp) <- c("Dataset","Subtype","Count")
comp$Dataset <- factor(comp$Dataset, levels=c("GSE123302","GSE148450","GSE18123"))
p4b <- ggplot(comp, aes(x=Dataset, y=Count, fill=Subtype)) +
  geom_bar(stat="identity", position="fill", alpha=0.85) +
  geom_text(aes(label=Count), position=position_fill(vjust=0.5), size=4, color="white") +
  scale_fill_manual(values=c("ASD-Immune"="#E41A1C","ASD-Synaptic"="#377EB8")) +
  labs(title="Subtype Composition Across Datasets", subtitle="Both partitions present in all three blood datasets",
       x="", y="Proportion") + theme_pub
ggsave(file.path(figdir,"Figure_4_panel_B.png"), p4b, width=7, height=5, dpi=200)

# ====================================================================
# Figure 5: ROC + LODO
# ====================================================================
cat("--- Figure 5 ---\n")
lodo <- mod5$lodo_results
lodo$Stage <- c("Prenatal","Birth","Childhood")[match(lodo$Holdout, c("GSE148450","GSE123302","GSE18123"))]
lodo$Label <- paste0(lodo$Stage, "\n(", lodo$Holdout, ")")
lodo$Label <- factor(lodo$Label, levels=lodo$Label[order(lodo$AUC)])

p5a <- ggplot(lodo, aes(x=Label, y=AUC, fill=Stage)) +
  geom_bar(stat="identity", alpha=0.85, width=0.5) +
  geom_text(aes(label=sprintf("%.3f", AUC)), vjust=-0.3, size=3.5) +
  geom_hline(yintercept=mean(lodo$AUC), linetype="dashed", color="gray50") +
  annotate("text", x=2, y=mean(lodo$AUC)+0.04, label=sprintf("Mean = %.3f", mean(lodo$AUC)), color="gray50", size=3.5) +
  scale_fill_brewer(palette="Set2") +
  labs(title="Leave-One-Dataset-Out Cross-Validation",
       subtitle=sprintf("Nested feature selection in each fold | Main AUC=%.3f (%.3f-%.3f)",
                        mod5$main_auc, mod5$main_ci[1], mod5$main_ci[3]),
       x="", y="AUC") + ylim(0,1) + theme_pub + theme(legend.position="none")
ggsave(file.path(figdir,"Figure_5_panel_A.png"), p5a, width=8, height=6, dpi=200)

# Panel B: Permutation null
perm_df <- data.frame(AUC=mod5$perm_aucs)
p5b <- ggplot(perm_df, aes(x=AUC)) +
  geom_histogram(bins=30, fill="gray70") + geom_vline(xintercept=mod5$main_auc, color="#E41A1C", linewidth=1.5) +
  geom_vline(xintercept=0.5, linetype="dashed", color="gray50") +
  annotate("text", x=mod5$main_auc+0.03, y=max(table(cut(mod5$perm_aucs,30)))*0.8,
           label=sprintf("Obs=%.3f\np=%.3f", mod5$main_auc, mod5$permutation_p), hjust=0, color="#E41A1C", size=3.5) +
  labs(title="Permutation Test (500 iterations)", x="AUC", y="Frequency") + theme_pub
ggsave(file.path(figdir,"Figure_5_panel_B.png"), p5b, width=6, height=5, dpi=200)

# ====================================================================
# Figure 6: PPV by Prevalence + M-CHAT-R comparison
# ====================================================================
cat("--- Figure 6 ---\n")
prevalences <- seq(0.005, 0.20, by=0.002)
model_ppv <- sapply(prevalences, function(p) (0.33*p)/(0.33*p + (1-0.36)*(1-p)))
mchat_ppv <- sapply(prevalences, function(p) (0.85*p)/(0.85*p + (1-0.85)*(1-p)))
ppv_df <- rbind(
  data.frame(Prevalence=prevalences*100, PPV=model_ppv, Test="20-Gene RF"),
  data.frame(Prevalence=prevalences*100, PPV=mchat_ppv, Test="M-CHAT-R")
)
p6a <- ggplot(ppv_df, aes(x=Prevalence, y=PPV, color=Test, linetype=Test)) +
  geom_line(linewidth=1.2) +
  geom_vline(xintercept=2, linetype="dashed", color="gray50") +
  annotate("text", x=3, y=0.15, label="2% population\nprevalence", size=3, color="gray50") +
  scale_color_manual(values=c("#E41A1C","#377EB8")) +
  labs(title="PPV by Disease Prevalence", x="ASD Prevalence (%)", y="Positive Predictive Value") +
  xlim(0,20) + ylim(0,1) + theme_pub
ggsave(file.path(figdir,"Figure_6_panel_A.png"), p6a, width=7, height=5, dpi=200)

# ====================================================================
# Figure 9: Single-Dataset Immune — Cord Blood (GSE123302)
# ====================================================================
cat("--- Figure 9 ---\n")
cts <- immune$ct_stats[["GSE123302"]]
cts$Diff_IS <- cts$Mean_Immune - cts$Mean_Synaptic
cts <- cts[order(-cts$Diff_IS),]
cts$Direction <- ifelse(cts$Diff_IS > 0, "Immune_elevated", "Immune_reduced")
cts$CellType <- factor(cts$CellType, levels=rev(cts$CellType))

p9a <- ggplot(cts, aes(x=CellType, y=Diff_IS, fill=Direction)) +
  geom_bar(stat="identity", alpha=0.85) +
  geom_hline(yintercept=0) +
  scale_fill_manual(values=c("Immune_elevated"="#E41A1C","Immune_reduced"="#377EB8")) +
  coord_flip() +
  labs(title="Immune Cell Differences: ASD-Immune vs ASD-Synaptic",
       subtitle="GSE123302 (Cord Blood, Birth) — single-dataset LM22 ssGSEA",
       x="", y="Score Difference (Immune - Synaptic)") + theme_pub + theme(legend.position="none")

# Add significance stars
sig_labels <- ifelse(cts$FDR_IS < 0.001, "***", ifelse(cts$FDR_IS < 0.01, "**", ifelse(cts$FDR_IS < 0.05, "*", "")))
p9a <- p9a + geom_text(aes(label=sig_labels, y=Diff_IS+sign(Diff_IS)*0.005), size=4)
ggsave(file.path(figdir,"Figure_9_panel_A.png"), p9a, width=8, height=6, dpi=200)

# Panel B: Cross-dataset consistency
consensus_top <- c("B_cells_naive","B_cells_memory","Monocytes","Neutrophils",
                   "Macrophages_M1","Macrophages_M2","T_cells_regulatory_Tregs","T_cells_follicular_helper")
heat_data <- matrix(NA, nrow=length(consensus_top), ncol=3)
rownames(heat_data) <- consensus_top
colnames(heat_data) <- c("Cord Blood\n(GSE123302)","Maternal Blood\n(GSE148450)","Childhood Blood\n(GSE18123)")
for(ds in c("GSE123302","GSE148450","GSE18123")) {
  ctd <- immune$ct_stats[[ds]]
  rn <- match(consensus_top, ctd$CellType)
  heat_data[,colnames(heat_data)[grep(ds,colnames(heat_data))]] <- ctd$Mean_Immune[rn] - ctd$Mean_Synaptic[rn]
}
png(file.path(figdir,"Figure_9_panel_B.png"), width=8, height=6, units="in", res=200)
pheatmap(heat_data, cluster_rows=FALSE, cluster_cols=FALSE,
         color=colorRampPalette(c("#377EB8","white","#E41A1C"))(100),
         display_numbers=TRUE, number_format="%.3f", fontsize_number=9,
         main="Immune Cell Score Difference (ASD-Immune - ASD-Synaptic)",
         fontsize=10, na_col="gray90")
dev.off()
cat("  Figure 9 done.\n")

# ====================================================================
# Figure 10: GTEx eQTL Tissue Specificity
# ====================================================================
cat("--- Figure 10 ---\n")
heat_mat <- as.matrix(eGene[,c("WB_NES","EBV_NES","Brain_NES")])
rownames(heat_mat) <- eGene$Gene
anno_row <- data.frame(Category=eGene$Category, row.names=eGene$Gene)
anno_colors <- list(Category=c("Immune-Tissue eQTL"="#E41A1C","Brain-Tissue eQTL"="#377EB8","Shared/Ambiguous"="gray70"))
png(file.path(figdir,"Figure_10_panel_A.png"), width=10, height=7, units="in", res=200)
pheatmap(heat_mat, cluster_rows=TRUE, cluster_cols=FALSE,
         color=colorRampPalette(c("white","#377EB8","#E41A1C"))(100),
         display_numbers=TRUE, number_format="%.2f", fontsize_number=8,
         main=sprintf("GTEx v8 Tissue-Specific eQTL NES\n%d Immune | %d Brain | %d Shared",
                      sum(eGene$Category=="Immune-Tissue eQTL"), sum(eGene$Category=="Brain-Tissue eQTL"),
                      sum(eGene$Category=="Shared/Ambiguous")),
         annotation_row=anno_row, annotation_colors=anno_colors)
dev.off()

# Panel B: Brain vs Blood scatter
eGene$Total_Immune <- eGene$WB_NES + eGene$EBV_NES
p10b <- ggplot(eGene, aes(x=Total_Immune, y=Brain_NES, color=Category, label=Gene)) +
  geom_point(size=3, alpha=0.85) +
  ggrepel::geom_text_repel(size=3, max.overlaps=20) +
  scale_color_manual(values=c("Immune-Tissue eQTL"="#E41A1C","Brain-Tissue eQTL"="#377EB8","Shared/Ambiguous"="gray50")) +
  geom_abline(slope=1, intercept=0, linetype="dashed", color="gray70") +
  labs(title="eQTL Tissue Specificity: Immune vs Brain",
       subtitle=sprintf("12 immune-tissue (8x bias) | 5 brain-tissue (missed by blood MR) | 3 shared"),
       x="Immune eQTL NES (WB + EBV)", y="Brain Cortex eQTL NES") + theme_pub
ggsave(file.path(figdir,"Figure_10_panel_B.png"), p10b, width=9, height=7, dpi=200)

# ====================================================================
# Figure S1 (NEW): Brain vs Blood eQTL Colocalization Comparison
# ====================================================================
cat("--- Figure S1: Brain vs Blood Coloc ---\n")
coloc_compare <- data.frame(
  Context = rep(c("Blood eQTL (eQTLGen, N=31684)","Brain eQTL (GTEx, N=200)"), each=3),
  Hypothesis = rep(c("H1 (eQTL only)","H3 (Independent)","H4 (Colocalized)"), 2),
  Probability = c(0.97, 0.002, 0.021, 0.00, 1.000, 0.000),
  stringsAsFactors = FALSE
)
p_s1 <- ggplot(coloc_compare, aes(x=Hypothesis, y=Probability, fill=Context)) +
  geom_bar(stat="identity", position="dodge", alpha=0.85) +
  geom_text(aes(label=sprintf("%.3f",Probability)), position=position_dodge(0.9), vjust=-0.3, size=3) +
  scale_fill_manual(values=c("Blood eQTL (eQTLGen, N=31684)"="#E41A1C","Brain eQTL (GTEx, N=200)"="#377EB8")) +
  labs(title="Colocalization: Blood vs Brain eQTL Contexts",
       subtitle="8 evaluable genes — neither context supports shared causal variants",
       x="", y="Posterior Probability") + ylim(0,1.1) + theme_pub
ggsave(file.path(figdir,"Figure_S1_coloc_comparison.png"), p_s1, width=8, height=5, dpi=200)

# ====================================================================
# Figure S2: Brain eQTL Instrument Strength (Z-score comparison)
# ====================================================================
cat("--- Figure S2: eQTL Instrument Strength ---\n")
z_compare <- data.frame(
  Gene = eGene$Gene,
  Z_Blood = with(eGene, pmax(WB_NES, EBV_NES) * sqrt(31684)),
  Z_Brain = eGene$Brain_NES * sqrt(200),
  Category = eGene$Category,
  stringsAsFactors = FALSE
)
z_compare <- z_compare[order(-z_compare$Z_Blood),]
z_compare$Gene <- factor(z_compare$Gene, levels=rev(z_compare$Gene))
z_melt <- reshape2::melt(z_compare, id.vars=c("Gene","Category"), variable.name="Tissue", value.name="Z")
p_s2 <- ggplot(z_melt, aes(x=Gene, y=Z, fill=Tissue)) +
  geom_bar(stat="identity", position="dodge", alpha=0.85) +
  geom_hline(yintercept=10, linetype="dashed", color="gray50") +
  annotate("text", x=18, y=12, label="F>10 threshold", size=3, color="gray50") +
  coord_flip() +
  scale_fill_manual(values=c("Z_Blood"="#E41A1C","Z_Brain"="#377EB8"), labels=c("Blood eQTL (N=31,684)","Brain eQTL (N=200)")) +
  labs(title="eQTL Instrument Strength: Blood vs Brain",
       subtitle="Brain eQTL instruments are 10-50x weaker — structural double bind",
       x="", y="Z-score") + theme_pub
ggsave(file.path(figdir,"Figure_S2_instrument_strength.png"), p_s2, width=9, height=7, dpi=200)

# ====================================================================
# COMPLETE
# ====================================================================
cat("\n===== All figures regenerated =====\n")
cat(sprintf("Figures saved to: %s\n", figdir))
for(f in sort(list.files(figdir, pattern="\\.png$"))) {
  cat(sprintf("  %s\n", f))
}

# ====================================================================
# REGENERATE Figure 10 + S1 + S2 with correct column names
# ====================================================================
cat("\n--- Figure 10 (fixed column names) ---\n")
eGene <- mod10$eGene_classification

heat_mat <- as.matrix(eGene[,c("WB","EBV","Brain")])
rownames(heat_mat) <- eGene$Gene
anno_row <- data.frame(Category=eGene$Category, row.names=eGene$Gene)
anno_colors <- list(Category=c("Immune-Tissue eQTL"="#E41A1C","Brain-Tissue eQTL"="#377EB8","Shared/Ambiguous"="gray70"))
png(file.path(figdir,"Figure_10_panel_A.png"), width=10, height=7, units="in", res=200)
pheatmap(heat_mat, cluster_rows=TRUE, cluster_cols=FALSE,
         color=colorRampPalette(c("white","#377EB8","#E41A1C"))(100),
         display_numbers=TRUE, number_format="%.2f", fontsize_number=8,
         main="GTEx v8 Tissue-Specific eQTL NES (Whole Blood + EBV + Brain Cortex)",
         annotation_row=anno_row, annotation_colors=anno_colors)
dev.off()

eGene$Total_Immune <- eGene$WB + eGene$EBV
p10b <- ggplot(eGene, aes(x=Total_Immune, y=Brain, color=Category, label=Gene)) +
  geom_point(size=3, alpha=0.85) +
  geom_text(vjust=-0.8, size=2.8, show.legend=FALSE, check_overlap=TRUE) +
  scale_color_manual(values=c("Immune-Tissue eQTL"="#E41A1C","Brain-Tissue eQTL"="#377EB8","Shared/Ambiguous"="gray50")) +
  geom_abline(slope=1, intercept=0, linetype="dashed", color="gray70") +
  annotate("text", x=1.3, y=0.05, hjust=0, size=3, color="gray40",
           label=sprintf("12 immune-tissue genes\n(mean blood/brain ratio = 5.5x)\n\n5 brain-tissue genes\n(missed by blood eQTL MR)")) +
  labs(title="eQTL Tissue Specificity: Immune vs Brain",
       subtitle="Blood eQTL instruments systematically enrich for immune genes",
       x="Immune eQTL NES (WB + EBV)", y="Brain Cortex eQTL NES") + theme_pub
ggsave(file.path(figdir,"Figure_10_panel_B.png"), p10b, width=9, height=7, dpi=200)

# S1
cat("--- Figure S1 ---\n")
coloc_compare <- data.frame(
  Context = rep(c("Blood eQTL (eQTLGen, N=31,684)","Brain eQTL (GTEx, N=200)"), each=3),
  Hypothesis = rep(c("H1 (eQTL only)","H3 (Independent)","H4 (Colocalized)"), 2),
  Probability = c(0.97, 0.002, 0.021, 0.00, 1.000, 0.000)
)
p_s1 <- ggplot(coloc_compare, aes(x=Hypothesis, y=Probability, fill=Context)) +
  geom_bar(stat="identity", position="dodge", alpha=0.85) +
  geom_text(aes(label=sprintf("%.3f",Probability)), position=position_dodge(0.9), vjust=-0.3, size=3) +
  scale_fill_manual(values=c("Blood eQTL (eQTLGen, N=31,684)"="#E41A1C","Brain eQTL (GTEx, N=200)"="#377EB8")) +
  labs(title="Colocalization: Blood vs Brain eQTL Contexts",
       subtitle="8 evaluable genes — neither context supports shared causal variants (H4)",
       x="", y="Posterior Probability") + ylim(0,1.15) + theme_pub
ggsave(file.path(figdir,"Figure_S1_coloc_comparison.png"), p_s1, width=8, height=5, dpi=200)

# S2
cat("--- Figure S2 ---\n")
z_compare <- data.frame(
  Gene = eGene$Gene,
  Z_Blood = with(eGene, pmax(WB, EBV) * sqrt(31684)),
  Z_Brain = eGene$Brain * sqrt(200),
  Category = eGene$Category
)
z_compare <- z_compare[order(-z_compare$Z_Blood),]
z_compare$Gene <- factor(z_compare$Gene, levels=rev(z_compare$Gene))
z_melt <- reshape2::melt(z_compare, id.vars=c("Gene","Category"), variable.name="Tissue", value.name="Z")
z_melt$Tissue <- ifelse(z_melt$Tissue=="Z_Blood", "Blood eQTL (N=31,684)", "Brain eQTL (N=200)")
p_s2 <- ggplot(z_melt, aes(x=Gene, y=Z, fill=Tissue)) +
  geom_bar(stat="identity", position="dodge", alpha=0.85) +
  geom_hline(yintercept=10, linetype="dashed", color="gray50") +
  annotate("text", x=19, y=14, label="F>10", size=3, color="gray50") +
  coord_flip() +
  scale_fill_manual(values=c("Blood eQTL (N=31,684)"="#E41A1C","Brain eQTL (N=200)"="#377EB8")) +
  labs(title="eQTL Instrument Strength: Blood vs Brain",
       subtitle="Structural double bind: blood=strong but not tissue-specific; brain=specific but too weak",
       x="", y="Z-score") + theme_pub
ggsave(file.path(figdir,"Figure_S2_instrument_strength.png"), p_s2, width=9, height=7, dpi=200)

cat("\n===== ALL FIGURES COMPLETE =====\n")
for(f in sort(list.files(figdir, pattern="\\.png$"))) {
  cat(sprintf("  %s\n", f))
}
