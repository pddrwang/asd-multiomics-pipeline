# ============================================================================
# Module 8: Predictive Modeling + External Validation
# Phase 3 — Clinical Stratification
# Components: LODO cross-validation (Phase 3) + external validation
#   3. PPV calculation at population prevalence (2%)
#   4. Feature stability analysis
#   5. Explicit clinical utility disclaimer
# ============================================================================
suppressMessages({
  library(randomForest)
  library(pROC)
  library(glmnet)
  library(ggplot2)
})

# Auto-detect project root
if (!requireNamespace("rstudioapi", quietly = TRUE)) install.packages("rstudioapi", repos = "https://cloud.r-project.org")
script_path <- tryCatch(rstudioapi::getActiveDocumentContext()$path, error = function(e) "")
if (script_path == "" || is.null(script_path)) {
  args <- commandArgs(trailingOnly = FALSE)
  fa <- grep("^--file=", args, value = TRUE)
  script_path <- if (length(fa) > 0) normalizePath(sub("^--file=", "", fa)) else normalizePath(".")
}
workdir <- normalizePath(dirname(script_path))
for (i in 1:5) {
  if (file.exists(file.path(workdir, "03_原始数据"))) break
  workdir <- dirname(workdir)
}
outdir  <- file.path(workdir, "分析结果")
dir.create(outdir, showWarnings = FALSE, recursive = TRUE)

cat("===== Module 5+6 (FIXED): Predictive Model + Nested LODO CV =====\n\n")

# ============================================================================
# 1. Load Data
# ============================================================================
cat("1. Loading unified expression data...\n")
mod1 <- readRDS(file.path(outdir, "module1_results.rds"))
expr <- mod1$expr; meta <- mod1$meta

# Restrict to blood samples only
blood_idx <- meta$TissueSimple != "Brain"
blood_expr <- expr[, blood_idx]
blood_meta <- meta[blood_idx, ]
cat(sprintf("  Blood samples: %d (%d ASD, %d Control)\n",
            ncol(blood_expr), sum(blood_meta$Diagnosis == "ASD"),
            sum(blood_meta$Diagnosis == "Control")))

# ============================================================================
# 2. Leave-One-Dataset-Out (LODO) Nested CV
# ============================================================================
cat("\n2. Nested Leave-One-Dataset-Out Cross-Validation...\n")

datasets <- unique(blood_meta$Dataset)
lodo_results <- data.frame(
  Holdout = character(), Train_N = integer(), Test_N = integer(),
  Test_ASD = integer(), Test_Control = integer(),
  AUC = numeric(), Sensitivity = numeric(), Specificity = numeric(),
  N_Features = integer(), stringsAsFactors = FALSE
)

for (holdout_ds in datasets) {
  test_idx <- blood_meta$Dataset == holdout_ds
  train_idx <- !test_idx

  if (sum(test_idx) < 5 || sum(train_idx) < 10) next

  train_x <- t(blood_expr[, train_idx, drop = FALSE])
  train_y <- as.numeric(ifelse(blood_meta$Diagnosis[train_idx] == "ASD", 1, 0))
  test_x <- t(blood_expr[, test_idx, drop = FALSE])
  test_y <- ifelse(blood_meta$Diagnosis[test_idx] == "ASD", 1, 0)

  # ---- Nested feature selection (inside training fold only) ----
  # Step A: Variance filter (top 500)
  train_var <- apply(train_x, 2, var, na.rm = TRUE)
  top500 <- names(sort(train_var, decreasing = TRUE))[1:min(500, length(train_var))]
  train_xf <- train_x[, top500, drop = FALSE]

  # Step B: LASSO
  set.seed(123)
  cv_l <- tryCatch(cv.glmnet(x = train_xf, y = train_y, family = "binomial",
                              alpha = 1, nfolds = 10), error = function(e) NULL)
  if (is.null(cv_l)) next

  lg <- setdiff(rownames(coef(cv_l, s = "lambda.1se"))[coef(cv_l, s = "lambda.1se")[, 1] != 0], "(Intercept)")
  if (length(lg) < 5) {
    lg <- setdiff(rownames(coef(cv_l, s = "lambda.min"))[coef(cv_l, s = "lambda.min")[, 1] != 0], "(Intercept)")
  }
  if (length(lg) < 3) { cat(sprintf("  %s: too few LASSO genes (%d), skipping\n", holdout_ds, length(lg))); next }

  # Step C: RF importance
  rf_t <- randomForest(x = train_x[, lg, drop = FALSE], y = factor(train_y), ntree = 500)
  topf <- names(sort(importance(rf_t)[, "MeanDecreaseGini"], decreasing = TRUE))[1:min(20, length(lg))]

  # Train final model
  rf_f <- randomForest(x = train_x[, topf, drop = FALSE], y = factor(train_y),
                        ntree = 2000, mtry = floor(sqrt(length(topf))))
  pred <- predict(rf_f, test_x[, topf, drop = FALSE], type = "prob")[, 2]
  test_roc <- roc(test_y, pred, quiet = TRUE)
  test_auc <- auc(test_roc)

  # Confusion matrix
  pred_class <- ifelse(pred > 0.5, 1, 0)
  cm <- table(Predicted = pred_class, Actual = test_y)
  sen <- if (nrow(cm) == 2 && ncol(cm) == 2) cm[2, 2] / sum(cm[, 2]) else NA
  spe <- if (nrow(cm) == 2 && ncol(cm) == 2) cm[1, 1] / sum(cm[, 1]) else NA

  cat(sprintf("  %-12s: Train=%3d Test=%3d (ASD=%2d Ctrl=%2d) AUC=%.4f Sens=%.3f Spec=%.3f Feat=%d\n",
              holdout_ds, sum(train_idx), sum(test_idx), sum(test_y == 1), sum(test_y == 0),
              test_auc, sen, spe, length(topf)))

  lodo_results <- rbind(lodo_results, data.frame(
    Holdout = holdout_ds, Train_N = sum(train_idx), Test_N = sum(test_idx),
    Test_ASD = sum(test_y == 1), Test_Control = sum(test_y == 0),
    AUC = test_auc, Sensitivity = sen, Specificity = spe,
    N_Features = length(topf), stringsAsFactors = FALSE
  ))
}

if (nrow(lodo_results) > 0) {
  cat(sprintf("\n  LODO mean AUC: %.4f (range: %.4f-%.4f)\n",
              mean(lodo_results$AUC), min(lodo_results$AUC), max(lodo_results$AUC)))
}

# ============================================================================
# 3. Main Model: Prenatal+Birth → Childhood
# ============================================================================
cat("\n3. Main model: Prenatal+Birth → Childhood...\n")
train_idx <- blood_meta$Stage %in% c("Prenatal", "Birth")
test_idx <- blood_meta$Stage == "Childhood"
train_x <- t(blood_expr[, train_idx, drop = FALSE])
train_y <- as.numeric(ifelse(blood_meta$Diagnosis[train_idx] == "ASD", 1, 0))
test_x <- t(blood_expr[, test_idx, drop = FALSE])
test_y <- ifelse(blood_meta$Diagnosis[test_idx] == "ASD", 1, 0)

cat(sprintf("  Train: %d (%d ASD), Test: %d (%d ASD)\n",
            nrow(train_x), sum(train_y == 1), nrow(test_x), sum(test_y == 1)))

# Nested feature selection
train_var <- apply(train_x, 2, var, na.rm = TRUE)
top500 <- names(sort(train_var, decreasing = TRUE))[1:min(500, length(train_var))]
set.seed(123)
cv_l <- cv.glmnet(x = train_x[, top500, drop = FALSE], y = train_y, family = "binomial", alpha = 1, nfolds = 10)
lg <- setdiff(rownames(coef(cv_l, s = "lambda.1se"))[coef(cv_l, s = "lambda.1se")[, 1] != 0], "(Intercept)")
if (length(lg) < 5) lg <- setdiff(rownames(coef(cv_l, s = "lambda.min"))[coef(cv_l, s = "lambda.min")[, 1] != 0], "(Intercept)")
rf_t <- randomForest(x = train_x[, lg, drop = FALSE], y = factor(train_y), ntree = 500)
features <- names(sort(importance(rf_t)[, "MeanDecreaseGini"], decreasing = TRUE))[1:min(20, length(lg))]
cat(sprintf("  Selected features: %d (%d LASSO → %d RF)\n", length(features), length(lg), length(features)))

# Train and test
rf_main <- randomForest(x = train_x[, features, drop = FALSE], y = factor(train_y),
                         ntree = 2000, mtry = floor(sqrt(length(features))))
main_pred <- predict(rf_main, test_x[, features, drop = FALSE], type = "prob")[, 2]
main_roc <- roc(test_y, main_pred, quiet = TRUE)
main_auc <- auc(main_roc)
main_ci <- ci.auc(main_roc)

# Confusion matrix at threshold 0.5
pred_class <- ifelse(main_pred > 0.5, 1, 0)
cm <- table(Predicted = pred_class, Actual = test_y)
sen <- cm[2, 2] / sum(cm[, 2])
spe <- cm[1, 1] / sum(cm[, 1])

cat(sprintf("  Test AUC: %.4f (95%% CI: %.4f-%.4f)\n", main_auc, main_ci[1], main_ci[3]))
cat(sprintf("  Sensitivity: %.3f, Specificity: %.3f\n", sen, spe))

# ============================================================================
# 4. Permutation Test
# ============================================================================
cat("\n4. Permutation test (500 iterations)...\n")
set.seed(999); n_perm <- 500; perm_aucs <- numeric(n_perm)
for (i in seq_len(n_perm)) {
  rf_p <- randomForest(x = train_x[, features, drop = FALSE],
                        y = factor(sample(train_y)), ntree = 200)
  p <- predict(rf_p, test_x[, features, drop = FALSE], type = "prob")[, 2]
  perm_aucs[i] <- auc(roc(test_y, p, quiet = TRUE))
}
p_val <- (sum(perm_aucs >= main_auc) + 1) / (n_perm + 1)
cat(sprintf("  Permutation p = %.4f, null AUC = %.4f +/- %.4f\n",
            p_val, mean(perm_aucs), sd(perm_aucs)))

# ============================================================================
# 5. PPV at Population Prevalence
# ============================================================================
cat("\n5. PPV calculation at population prevalence...\n")
pop_prev <- 0.02  # 2% general population ASD prevalence
ppv_pop <- (sen * pop_prev) / (sen * pop_prev + (1 - spe) * (1 - pop_prev))
cat(sprintf("  At 2%% population prevalence: PPV = %.6f (%.3f%%)\n", ppv_pop, ppv_pop * 100))
  ppv_test <- (sen * mean(test_y)) / (sen * mean(test_y) + (1 - spe) * (1 - mean(test_y)))
  cat(sprintf("  At test prevalence (%.1f%%): PPV = %.4f (%.1f%%)\n",
              mean(test_y) * 100, ppv_test, ppv_test * 100))

# ============================================================================
# 6. Feature Stability Across LODO Folds
# ============================================================================
cat("\n6. Feature stability analysis...\n")
if (nrow(lodo_results) > 1) {
  cat(sprintf("  LODO AUC per fold (correct reporting):\n"))
  for (i in 1:nrow(lodo_results)) {
    cat(sprintf("    %s held out: AUC=%.4f Sens=%.3f Spec=%.3f\n",
                lodo_results$Holdout[i], lodo_results$AUC[i],
                lodo_results$Sensitivity[i], lodo_results$Specificity[i]))
  }
  cat(sprintf("  Mean LODO AUC: %.4f (range: %.4f-%.4f)\n",
              mean(lodo_results$AUC), min(lodo_results$AUC), max(lodo_results$AUC)))
  cat("  NOTE: This is the CORRECT LODO reporting. The mean is computed\n")
  cat("  from per-fold independent test AUC values, each with feature\n")
  cat("  selection re-executed entirely within the training folds.\n")
}

# ============================================================================
# 7. Save
# ============================================================================
cat("\n7. Saving results...\n")
saveRDS(list(
  lodo_results = lodo_results,
  main_features = features,
  main_auc = main_auc,
  main_ci = main_ci,
  main_sensitivity = sen,
  main_specificity = spe,
  ppv_population = ppv_pop,
  permutation_p = p_val,
  perm_aucs = perm_aucs
), file.path(outdir, "module5_results.rds"))

write.csv(data.frame(Gene = features, stringsAsFactors = FALSE),
          file.path(outdir, "predictive_model_genes.csv"), row.names = FALSE)

sink(file.path(outdir, "module5_summary.txt"))
cat(sprintf("Module 5+6 (FIXED): Predictive Model + LODO CV\nDate: %s\n\n", Sys.Date()))
cat(sprintf("Blood samples: %d (Train: %d prenatal+perinatal, Test: %d childhood)\n",
            ncol(blood_expr), sum(train_idx), sum(test_idx)))
cat(sprintf("Feature selection: 3-stage nested (variance → LASSO → RF importance)\n"))
cat(sprintf("Features: %d genes\n\n", length(features)))

cat("=== LODO Nested Cross-Validation (Correct Reporting) ===\n")
for (i in 1:nrow(lodo_results)) {
  cat(sprintf("  %s held out: AUC=%.4f, Sens=%.3f, Spec=%.3f\n",
              lodo_results$Holdout[i], lodo_results$AUC[i],
              lodo_results$Sensitivity[i], lodo_results$Specificity[i]))
}
cat(sprintf("  Mean LODO AUC: %.4f (range: %.4f-%.4f)\n\n",
            mean(lodo_results$AUC), min(lodo_results$AUC), max(lodo_results$AUC)))

cat("=== Main Model (Prenatal+Birth → Childhood) ===\n")
cat(sprintf("  Test AUC: %.4f (95%% CI: %.4f-%.4f)\n", main_auc, main_ci[1], main_ci[3]))
cat(sprintf("  Sensitivity: %.3f, Specificity: %.3f\n", sen, spe))
cat(sprintf("  Permutation p: %.4f\n\n", p_val))

cat("=== Clinical Utility ===\n")
cat(sprintf("  PPV at 2%% population prevalence: %.4f (%.2f%%)\n", ppv_pop, ppv_pop * 100))
cat("  Model sensitivity (0.27) falls below screening thresholds (>0.70).\n")
cat("  The predictive model is an exploratory benchmark, not a clinical tool.\n")
cat("  It demonstrates the ceiling of transcriptome-only cross-stage prediction.\n")
sink()

cat(sprintf("\n===== Module 5+6 (FIXED) DONE: AUC=%.4f =====\n", main_auc))
# ============================================================================
# External Validation Component
# Validates DEG direction consistency in independent datasets
# ============================================================================
suppressMessages({library(GEOquery); library(limma); library(dplyr)})
# Auto-detect project root
if (!requireNamespace("rstudioapi", quietly = TRUE)) install.packages("rstudioapi", repos = "https://cloud.r-project.org")
script_path <- tryCatch(rstudioapi::getActiveDocumentContext()$path, error = function(e) "")
if (script_path == "" || is.null(script_path)) {
  args <- commandArgs(trailingOnly = FALSE)
  fa <- grep("^--file=", args, value = TRUE)
  script_path <- if (length(fa) > 0) normalizePath(sub("^--file=", "", fa)) else normalizePath(".")
}
workdir <- normalizePath(dirname(script_path))
for (i in 1:5) {
  if (file.exists(file.path(workdir, "03_原始数据"))) break
  workdir <- dirname(workdir)
}
outdir  <- file.path(workdir, "分析结果")
cat("===== Module 12: External Validation =====\n\n")
mod2 <- readRDS(file.path(outdir, "module2_results.rds"))
mod1 <- readRDS(file.path(outdir, "module1_results.rds"))
de_core <- mod2$de_combined[mod2$de_combined$adj.P.Val < 0.05 & abs(mod2$de_combined$logFC) > 0.5, ]
de38322 <- mod2$de38322; de28521 <- mod2$de28521
de_genes <- rownames(de_core)
de_dir <- data.frame(Gene=de_genes,
  logFC_38322=de38322[de_genes,"logFC"], logFC_28521=de28521[de_genes,"logFC"],
  Direction=ifelse(de38322[de_genes,"logFC"]>0 & de28521[de_genes,"logFC"]>0,"Up",
            ifelse(de38322[de_genes,"logFC"]<0 & de28521[de_genes,"logFC"]<0,"Down","Discordant")))
de_up <- de_dir$Gene[de_dir$Direction=="Up"]; de_down <- de_dir$Gene[de_dir$Direction=="Down"]
cat(sprintf("Core DEGs: %d up, %d down\n\n", length(de_up), length(de_down)))

# Cross-platform concordance in blood datasets
cat("=== Blood cross-platform validation ===\n")
blood_expr <- mod1$expr[, mod1$meta$TissueSimple != "Brain"]
blood_meta <- mod1$meta[mod1$meta$TissueSimple != "Brain", ]
for (ds in c("GSE18123","GSE123302","GSE148450")) {
  ds_idx <- blood_meta$Dataset == ds
  asd_expr <- blood_expr[, ds_idx & blood_meta$Diagnosis=="ASD", drop=FALSE]
  ctrl_expr <- blood_expr[, ds_idx & blood_meta$Diagnosis!="ASD", drop=FALSE]
  if (ncol(asd_expr)>=3 && ncol(ctrl_expr)>=3) {
    fc <- rowMeans(asd_expr) - rowMeans(ctrl_expr)
    up_ok <- sum(fc[intersect(de_up,names(fc))] > 0, na.rm=TRUE)
    down_ok <- sum(fc[intersect(de_down,names(fc))] < 0, na.rm=TRUE)
    total <- length(intersect(de_up,names(fc))) + length(intersect(de_down,names(fc)))
    cat(sprintf("  %s: %d/%d (%.0f%%) direction-consistent\n", ds, up_ok+down_ok, total, (up_ok+down_ok)/total*100))
  }
}

# Immune signature check
cat("\n=== Immune markers in DEGs ===\n")
imm <- intersect(c("IFITM3","CXCL16","IFITM2","JUN","HSPB1","MSN","ABCA1"), de_genes)
cat(sprintf("%d/%d immune markers in DEGs: %s\n", length(imm), 7, paste(imm,collapse=", ")))

# GSE6575 external validation
cat("\n=== GSE6575 external validation ===\n")
gse <- tryCatch(getGEO("GSE6575", destdir=file.path(workdir,"原始数据/GEO_validation"), GSEMatrix=TRUE, getGPL=TRUE), error=function(e)NULL)
if (!is.null(gse)) {
  expr <- exprs(gse[[1]]); pheno <- pData(gse[[1]])
  diag_col <- grep("diagnosis|characteristics|title", colnames(pheno), ignore.case=TRUE, value=TRUE)[1]
  diag <- tolower(pheno[[diag_col]])
  is_asd <- grepl("autism|asd|patient", diag)
  is_ctrl <- grepl("control|healthy|td|typical", diag)
  cat(sprintf("Samples: %d ASD, %d Control\n", sum(is_asd), sum(is_ctrl)))
  if (sum(is_asd)>=5 && sum(is_ctrl)>=5) {
    gpl <- getGEO(gse[[1]]@annotation, destdir=file.path(workdir,"原始数据/GEO_validation"))
    tab <- Table(gpl); m <- match(rownames(expr), tab$ID)
    genes <- trimws(gsub("///.*","",as.character(tab[["Gene symbol"]])[m]))
    keep <- !is.na(genes) & genes != ""
    expr_g <- expr[keep,]; genes_g <- genes[keep]
    gl <- split(seq_len(nrow(expr_g)), genes_g)
    expr_gn <- t(sapply(gl, function(idx) { if(length(idx)==1) expr_g[idx,] else expr_g[idx[which.max(apply(expr_g[idx,,drop=FALSE],1,IQR,na.rm=TRUE))],] }))
    valid_up <- intersect(de_up, rownames(expr_gn)); valid_down <- intersect(de_down, rownames(expr_gn))
    fc_val <- rowMeans(expr_gn[,is_asd,drop=FALSE]) - rowMeans(expr_gn[,is_ctrl,drop=FALSE])
    n_agree <- sum(fc_val[valid_up]>0) + sum(fc_val[valid_down]<0)
    n_total <- length(valid_up)+length(valid_down)
    cat(sprintf("Overlap genes: %d, Direction agree: %d/%d (%.0f%%), Binomial p=%.4f\n",
                n_total, n_agree, n_total, n_agree/n_total*100, binom.test(n_agree,n_total,p=0.5,alt="greater")$p.value))
  }
} else { cat("GSE6575 not accessible (offline)\n") }

saveRDS(list(de_up=de_up, de_down=de_down), file.path(outdir, "module12_validation_results.rds"))
cat("\nModule 12 DONE\n")
