# Module 3A: Per-SNP Coloc with REAL eQTLGen data
suppressMessages({library(coloc); library(data.table); library(dplyr)})

# Auto-detect project root
if (!requireNamespace("rstudioapi", quietly = TRUE)) install.packages("rstudioapi", repos = "https://cloud.r-project.org")
script_path <- tryCatch(rstudioapi::getActiveDocumentContext()$path, error = function(e) "")
if (script_path == "" || is.null(script_path)) {
  args <- commandArgs(trailingOnly = FALSE)
  fa <- grep("^--file=", args, value = TRUE)
  script_path <- if (length(fa) > 0) normalizePath(sub("^--file=", "", fa)) else normalizePath(".")
}
workdir <- normalizePath(dirname(script_path))
for (i in 1:5) {
  if (file.exists(file.path(workdir, "03_原始数据"))) break
  workdir <- dirname(workdir)
}
outdir  <- file.path(workdir, "分析结果")
eqtl_dir <- file.path(workdir, "原始数据/eQTL/per_gene_eqtl")
cat("===== Module 3A: Per-SNP Coloc (REAL eQTLGen + PGC GWAS) =====\n\n")

gene_files <- list.files(eqtl_dir, pattern="eqtlgen_.*\\.tsv$", full.names=TRUE)
cat(sprintf("Found %d per-gene eQTL files\n\n", length(gene_files)))

# Load GWAS
cat("Loading PGC ASD GWAS (9.1M SNPs)...\n")
gwas <- fread(file.path(workdir, "原始数据/GWAS/iPSYCH-PGC_ASD_Nov2017.gz"))
setnames(gwas, c("CHR","SNP","BP","A1","A2","INFO","OR","SE","P"))
gwas <- gwas[!grepl(":", SNP) & !is.na(P) & P>0 & P<1 & CHR!="CHR"]
gwas[, CHR := as.integer(CHR)]
gwas[, `:=`(GWAS_BETA = log(OR), GWAS_varbeta = SE^2)]
cat(sprintf("  SNPs: %d\n\n", nrow(gwas)))

# Parameters
prop_cases <- 18381 / 46350
maf_approx  <- 0.25

coloc_full <- data.frame(stringsAsFactors=FALSE)

for (f in gene_files) {
  gene <- gsub("eqtlgen_|\\.tsv", "", basename(f))
  cat(sprintf("--- %s ---\n", gene))

  # Read eQTLGen data (columns: Pvalue SNP SNPChr SNPPos ... Zscore ... NrSamples)
  eqtl <- fread(f)
  if (nrow(eqtl) < 20) { cat("  < 20 SNPs, skip\n\n"); next }

  # Rename columns for clarity
  setnames(eqtl, old = c("SNPChr","SNPPos","AssessedAllele","OtherAllele","NrSamples"),
           new = c("eQTL_CHR","eQTL_BP","eQTL_A1","eQTL_A2","eQTL_N"),
           skip_absent = TRUE)

  # Compute per-SNP eQTL beta from Z-score
  # beta = Z / sqrt(2 * N * MAF * (1 - MAF))
  n_eqtl <- eqtl$eQTL_N[1]  # sample size (same for all SNPs in eQTLGen)
  se_eqtl <- 1 / sqrt(2 * n_eqtl * maf_approx * (1 - maf_approx))
  eqtl[, eQTL_BETA    := Zscore / sqrt(2 * eQTL_N * maf_approx * (1 - maf_approx))]
  eqtl[, eQTL_varbeta := se_eqtl^2]

  # Match to GWAS by rsID
  merged <- merge(eqtl[, .(SNP, eQTL_BETA, eQTL_varbeta)],
                  gwas[, .(SNP, GWAS_BETA, GWAS_varbeta)],
                  by = "SNP")
  cat(sprintf("  %d eQTL SNPs → %d matched GWAS\n", nrow(eqtl), nrow(merged)))

  if (nrow(merged) < 20) { cat("  < 20 matched, skip\n\n"); next }

  # LD pruning: keep top SNP per 50kb window (not 500kb — too wide for cis)
  merged <- merge(merged,
                  unique(eqtl[, .(SNP, eQTL_BP)]),
                  by = "SNP", all.x = TRUE)
  merged[, window := floor(eQTL_BP / 50000)]
  setorder(merged, window)
  # Keep the SNP with smallest GWAS p-value per window
  merged_pruned <- merged[order(window, abs(GWAS_BETA)/sqrt(GWAS_varbeta), decreasing = TRUE)]
  merged_pruned <- merged_pruned[!duplicated(window)]
  cat(sprintf("  After LD pruning (50kb): %d SNPs\n", nrow(merged_pruned)))

  if (nrow(merged_pruned) < 20) { cat("  < 20 after pruning, skip\n\n"); next }

  # Run coloc
  cr <- tryCatch({
    coloc.abf(
      dataset1 = list(snp = merged_pruned$SNP,
                      beta = merged_pruned$eQTL_BETA,
                      varbeta = merged_pruned$eQTL_varbeta,
                      type = "quant",
                      N = n_eqtl,
                      MAF = rep(maf_approx, nrow(merged_pruned))),
      dataset2 = list(snp = merged_pruned$SNP,
                      beta = merged_pruned$GWAS_BETA,
                      varbeta = merged_pruned$GWAS_varbeta,
                      type = "cc",
                      N = 46350,
                      MAF = rep(maf_approx, nrow(merged_pruned)),
                      s = prop_cases)
    )
  }, error = function(e) NULL)

  if (is.null(cr)) { cat("  coloc failed\n\n"); next }

  pp <- cr$summary
  coloc_full <- rbind(coloc_full, data.frame(
    Gene = gene,
    N_eQTL_SNPs = nrow(eqtl),
    N_Matched   = nrow(merged),
    N_Pruned    = nrow(merged_pruned),
    PP_H0 = pp["PP.H0.abf"],
    PP_H1 = pp["PP.H1.abf"],
    PP_H2 = pp["PP.H2.abf"],
    PP_H3 = pp["PP.H3.abf"],
    PP_H4 = pp["PP.H4.abf"],
    stringsAsFactors = FALSE
  ))
  cat(sprintf("  PP.H4=%.4f  PP.H3=%.4f  PP.H0=%.4f\n\n",
              pp["PP.H4.abf"], pp["PP.H3.abf"], pp["PP.H0.abf"]))
}

# Summary
if (nrow(coloc_full) > 0) {
  coloc_full <- coloc_full[order(-coloc_full$PP_H4), ]
}
cat("========== RESULTS ==========\n\n")
cat(sprintf("Evaluated: %d genes\n", nrow(coloc_full)))
cat(sprintf("PP.H4 > 0.50:  %d genes\n", sum(coloc_full$PP_H4 > 0.50)))
cat(sprintf("PP.H4 > 0.80:  %d genes\n", sum(coloc_full$PP_H4 > 0.80)))
cat(sprintf("PP.H4 > 0.95:  %d genes\n\n", sum(coloc_full$PP_H4 > 0.95)))

cat(sprintf("%-12s %6s %6s %6s %8s %8s %8s %8s %8s\n",
            "Gene","eQTL","Match","Pruned","PP.H4","PP.H3","PP.H2","PP.H1","PP.H0"))
cat(rep("-", 80), "\n", sep = "")
for (j in 1:nrow(coloc_full)) {
  cat(sprintf("%-12s %6d %6d %6d %8.4f %8.4f %8.4f %8.4f %8.4f\n",
              coloc_full$Gene[j], coloc_full$N_eQTL_SNPs[j],
              coloc_full$N_Matched[j], coloc_full$N_Pruned[j],
              coloc_full$PP_H4[j], coloc_full$PP_H3[j],
              coloc_full$PP_H2[j], coloc_full$PP_H1[j],
              coloc_full$PP_H0[j]))
}

# Save
saveRDS(coloc_full, file.path(outdir, "module3_adv_coloc_results.rds"))
fwrite(coloc_full, file.path(outdir, "coloc_per_snp_results.csv"))
cat(sprintf("\nModule 3A DONE — %d genes evaluated\n", nrow(coloc_full)))
cat(sprintf("Results: %s\n", file.path(outdir, "coloc_per_snp_results.csv")))
