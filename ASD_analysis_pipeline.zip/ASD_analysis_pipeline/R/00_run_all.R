# ============================================================================
# 00_run_all.R — Complete 11-Module Pipeline (Ground-Up Re-run)
# ============================================================================
suppressMessages({
  library(limma); library(sva); library(org.Hs.eg.db); library(AnnotationDbi); library(GEOquery)
  library(ggplot2); library(data.table); library(dplyr)
  library(ConsensusClusterPlus); library(pheatmap); library(randomForest)
  library(glmnet); library(pROC); library(GSVA); library(reshape2); library(coloc)
})

# Auto-detect project root
if (!requireNamespace("rstudioapi", quietly = TRUE)) install.packages("rstudioapi", repos = "https://cloud.r-project.org")
script_path <- tryCatch(rstudioapi::getActiveDocumentContext()$path, error = function(e) "")
if (script_path == "" || is.null(script_path)) {
  args <- commandArgs(trailingOnly = FALSE)
  fa <- grep("^--file=", args, value = TRUE)
  script_path <- if (length(fa) > 0) normalizePath(sub("^--file=", "", fa)) else normalizePath(".")
}
workdir <- normalizePath(dirname(script_path))
for (i in 1:5) {
  if (file.exists(file.path(workdir, "03_原始数据"))) break
  workdir <- dirname(workdir)
}
datadir <- file.path(workdir, "原始数据/GEO")
outdir  <- file.path(workdir, "分析结果")
figdir  <- file.path(outdir, "figures")
dir.create(figdir, showWarnings=FALSE, recursive=TRUE)

cat("============================================\n")
cat("ASD Multi-Omics Pipeline — COMPLETE RE-RUN\n")
cat(sprintf("Started: %s\n", Sys.time()))
cat("============================================\n\n")

collapse_to_genes <- function(expr, gene_symbols) {
  gene_list <- split(seq_len(nrow(expr)), gene_symbols)
  t(sapply(gene_list, function(idx) {
    if (length(idx) == 1) return(expr[idx, ])
    iqrs <- apply(expr[idx, , drop=FALSE], 1, IQR, na.rm=TRUE)
    expr[idx[which.max(iqrs)], ]
  }))
}

# ============================
# MODULE 1: 5-Dataset Integration
# ============================
cat("########## MODULE 1 ##########\n")
t0 <- Sys.time()

# GSE18123
cat("1/5 GSE18123...\n")
e1 <- as.matrix(read.csv(file.path(datadir,"GSE18123/GSE18123_expression_matrix_log2.csv"),row.names=1,check.names=FALSE))
gpl570 <- getGEO(filename=file.path(datadir,"GSE18123/GPL570.annot.gz"))
tab1 <- Table(gpl570); m1 <- match(rownames(e1),tab1$ID)
g1 <- trimws(gsub("///.*","",as.character(tab1[["Gene symbol"]])[m1]))
keep <- !is.na(g1)&g1!=""; e1<-e1[keep,]; g1<-g1[keep]
e1g <- collapse_to_genes(e1,g1)
pheno1<-read.csv(file.path(datadir,"GSE18123/GSE18123_group_info.csv"),stringsAsFactors=FALSE)
rownames(pheno1)<-pheno1$Sample; pheno1<-pheno1[colnames(e1),]
diag1<-trimws(gsub("^diagnosis:\\s*","",pheno1$Diagnosis,ignore.case=FALSE))
grp1<-ifelse(diag1=="CONTROL","Control",ifelse(diag1%in%c("AUTISM","ASPERGER'S DISORDER","PDD-NOS"),"ASD","Other"))
keep_s<-grp1%in%c("ASD","Control"); e1g<-e1g[,keep_s]; grp1<-grp1[keep_s]
colnames(e1g)<-paste0("GSE18123_",colnames(e1g))
cat(sprintf("  %d genes x %d samples (%d ASD, %d Control)\n",nrow(e1g),ncol(e1g),sum(grp1=="ASD"),sum(grp1=="Control")))

# GSE123302
cat("2/5 GSE123302...\n")
e2<-as.matrix(read.csv(file.path(datadir,"GSE123302/GSE123302_expression_matrix.csv"),row.names=1,check.names=FALSE))
gpl16686<-getGEO(filename=file.path(datadir,"GSE123302/GPL16686.soft.gz"))
tab2<-Table(gpl16686); m2<-match(rownames(e2),tab2$ID)
acc2<-as.character(tab2$GB_ACC)[m2]; valid2<-acc2!=""&!is.na(acc2)
sym2<-rep(NA,length(acc2))
if(any(valid2)){mapped<-suppressMessages(AnnotationDbi::select(org.Hs.eg.db,keys=acc2[valid2],columns="SYMBOL",keytype="REFSEQ"));mapped<-mapped[!duplicated(mapped$REFSEQ),];mm<-match(acc2,mapped$REFSEQ);sym2<-mapped$SYMBOL[mm]}
keep<-!is.na(sym2)&sym2!=""; e2<-e2[keep,]; sym2<-sym2[keep]
e2g<-collapse_to_genes(e2,sym2)
pheno2<-read.csv(file.path(datadir,"GSE123302/GSE123302_group_info.csv"),stringsAsFactors=FALSE)
grp2<-pheno2$Group;grp2[grp2=="TD"]<-"Control"
colnames(e2g)<-paste0("GSE123302_",colnames(e2g))
cat(sprintf("  %d genes x %d samples (%d ASD, %d Control)\n",nrow(e2g),ncol(e2g),sum(grp2=="ASD"),sum(grp2=="Control")))

# GSE148450
cat("3/5 GSE148450...\n")
e3<-as.matrix(read.csv(file.path(datadir,"GSE148450/GSE148450_expression_matrix.csv"),row.names=1,check.names=FALSE))
g3<-rownames(e3); keep<-!is.na(g3)&g3!=""&!grepl("^\\d",g3)
e3<-e3[keep,]; g3<-g3[keep]; e3g<-collapse_to_genes(e3,g3)
pheno3<-read.csv(file.path(datadir,"GSE148450/GSE148450_group_info.csv"),stringsAsFactors=FALSE)
grp3<-pheno3$Group;grp3[grp3=="TD"]<-"Control"
colnames(e3g)<-paste0("GSE148450_",colnames(e3g))
cat(sprintf("  %d genes x %d samples (%d ASD, %d Control)\n",nrow(e3g),ncol(e3g),sum(grp3=="ASD"),sum(grp3=="Control")))

# GSE38322
cat("4/5 GSE38322...\n")
e4<-as.matrix(read.csv(file.path(datadir,"GSE38322/GSE38322_expression_matrix.csv"),row.names=1,check.names=FALSE))
gpl10558<-getGEO(filename=file.path(datadir,"GSE38322/GPL10558.annot.gz"))
tab4<-Table(gpl10558); m4<-match(rownames(e4),tab4$ID)
g4<-trimws(as.character(tab4[["Gene symbol"]])[m4])
keep<-!is.na(g4)&g4!=""; e4<-e4[keep,]; g4<-g4[keep]; e4g<-collapse_to_genes(e4,g4)
diag4<-readRDS(file.path(datadir,"GSE38322/GSE38322_diagnosis.rds")); diag4<-diag4[colnames(e4)]
colnames(e4g)<-paste0("GSE38322_",colnames(e4g))
cat(sprintf("  %d genes x %d samples (%d ASD, %d Control)\n",nrow(e4g),ncol(e4g),sum(diag4=="ASD"),sum(diag4=="Control")))

# GSE28521
cat("5/5 GSE28521...\n")
gse28521<-getGEO(filename=file.path(datadir,"GSE28521/GSE28521_series_matrix.txt.gz"),AnnotGPL=FALSE,getGPL=FALSE)
e5<-exprs(gse28521)
char5<-as.character(pData(gse28521)$characteristics_ch1)
diag5<-ifelse(grepl("autism",char5),"ASD",ifelse(grepl("controls",char5),"Control","Other"))
names(diag5)<-colnames(e5)
gpl6883<-getGEO(filename=file.path(datadir,"GSE28521/GPL6883.annot.gz"))
tab5<-Table(gpl6883); m5<-match(rownames(e5),tab5$ID)
g5<-trimws(as.character(tab5[["Gene symbol"]])[m5])
keep<-!is.na(g5)&g5!=""; e5<-e5[keep,]; g5<-g5[keep]; e5g<-collapse_to_genes(e5,g5)
diag5<-diag5[colnames(e5)]
colnames(e5g)<-paste0("GSE28521_",colnames(e5g))
cat(sprintf("  %d genes x %d samples (%d ASD, %d Control)\n",nrow(e5g),ncol(e5g),sum(diag5=="ASD"),sum(diag5=="Control")))

# Intersection + Filter + QN + NA handling + ComBat + Metadata + PCA + Save
cat("\n6. Gene intersection + batch correction...\n")
common<-Reduce(intersect,list(rownames(e1g),rownames(e2g),rownames(e3g),rownames(e4g),rownames(e5g)))
cat(sprintf("  Common genes: %d\n",length(common)))
m1f<-e1g[common,]; m2f<-e2g[common,]; m3f<-e3g[common,]; m4f<-e4g[common,]; m5f<-e5g[common,]
unified<-cbind(m1f,m2f,m3f,m4f,m5f)
gene_rate<-rowMeans(unified>2); unified<-unified[gene_rate>=0.10,]
batch<-rep(c("GSE18123","GSE123302","GSE148450","GSE38322","GSE28521"),c(ncol(m1f),ncol(m2f),ncol(m3f),ncol(m4f),ncol(m5f)))
for(b in unique(batch)){idx<-which(batch==b); unified[,idx]<-normalizeBetweenArrays(unified[,idx],method="quantile")}
gene_na_rate<-rowMeans(is.na(unified)); unified<-unified[gene_na_rate<=0.20,]
na_count<-sum(is.na(unified))
if(na_count>0){for(i in seq_len(nrow(unified))){na_idx<-which(is.na(unified[i,])); if(length(na_idx)>0&&length(na_idx)<ncol(unified)){rm<-median(unified[i,],na.rm=TRUE); if(!is.na(rm))unified[i,na_idx]<-rm}}}
diagnosis<-c(grp1,grp2,grp3,diag4,diag5); names(diagnosis)<-colnames(unified)
tissue<-c(rep("Peripheral_Blood",ncol(m1f)),rep("Cord_Blood",ncol(m2f)),rep("Maternal_Blood",ncol(m3f)),rep("Brain_GSE38322",ncol(m4f)),rep("Brain_GSE28521",ncol(m5f)))
tissue_simple<-ifelse(grepl("Brain",tissue),"Brain",ifelse(tissue=="Cord_Blood","Cord_Blood",ifelse(tissue=="Maternal_Blood","Maternal_Blood","Peripheral_Blood")))
stage<-c(rep("Childhood",ncol(m1f)),rep("Birth",ncol(m2f)),rep("Prenatal",ncol(m3f)),rep("Postmortem",ncol(m4f)),rep("Postmortem",ncol(m5f)))
meta<-data.frame(Sample=colnames(unified),Dataset=batch,Tissue=tissue,TissueSimple=tissue_simple,Stage=stage,Diagnosis=diagnosis,stringsAsFactors=FALSE)
rownames(meta)<-meta$Sample
cat(sprintf("  Blood: %d, Brain: %d\n",sum(meta$TissueSimple!="Brain"),sum(meta$TissueSimple=="Brain")))
mod_combat<-model.matrix(~Diagnosis,data=meta)
unified_corrected<-ComBat(dat=unified,batch=batch,mod=mod_combat,par.prior=TRUE,prior.plots=FALSE)
pca_res<-prcomp(t(unified_corrected),center=TRUE,scale.=TRUE,rank.=50)
pca_var<-summary(pca_res)$importance[2,]*100
batch_r2<-sapply(1:10,function(i)summary(lm(pca_res$x[,i]~meta$Dataset))$r.squared)
diag_r2<-sapply(1:10,function(i)summary(lm(pca_res$x[,i]~meta$Diagnosis))$r.squared)
tissue_r2<-sapply(1:10,function(i)summary(lm(pca_res$x[,i]~meta$TissueSimple))$r.squared)
hk_genes<-intersect(c("GAPDH","ACTB","B2M","RPLP0","PPIA","HPRT1","TBP"),rownames(unified_corrected))
hk_cv<-NA
if(length(hk_genes)>=5){hk_expr<-unified_corrected[hk_genes,]; hk_cv<-mean(sapply(hk_genes,function(g){tmeans<-sapply(unique(meta$TissueSimple),function(t)mean(hk_expr[g,meta$TissueSimple==t])); sd(tmeans)/mean(tmeans)}))}
cat(sprintf("  PCA: PC1=%.1f%%, HK CV=%.4f\n",pca_var[1],hk_cv))
saveRDS(list(expr=unified_corrected,meta=meta,common_genes=common,pca_var=pca_var,batch_r2=batch_r2,diag_r2=diag_r2,tissue_r2=tissue_r2,hk_genes=hk_genes,hk_cv=hk_cv),file.path(outdir,"module1_results.rds"))
cat(sprintf("M1 DONE (%.1f min): %d genes x %d samples\n\n",difftime(Sys.time(),t0,units="mins"),nrow(unified_corrected),ncol(unified_corrected)))

# ============================
# MODULE 2: Brain DEG + Permutation
# ============================
cat("########## MODULE 2 ##########\n")
t0<-Sys.time()
gse38322<-getGEO(filename=file.path(datadir,"GSE38322/GSE38322_series_matrix.txt.gz"),AnnotGPL=FALSE,getGPL=FALSE)
gse28521<-getGEO(filename=file.path(datadir,"GSE28521/GSE28521_series_matrix.txt.gz"),AnnotGPL=FALSE,getGPL=FALSE)
expr38322_raw<-exprs(gse38322); expr28521_raw<-exprs(gse28521)
diag38322<-ifelse(sapply(strsplit(as.character(pData(gse38322)$source_name_ch1),"_"),`[`,1)=="Autism","ASD","Control")
diag28521<-ifelse(grepl("autism",as.character(pData(gse28521)$characteristics_ch1)),"ASD","Control")
names(diag38322)<-colnames(expr38322_raw); names(diag28521)<-colnames(expr28521_raw)
gpl10558<-getGEO(filename=file.path(datadir,"GSE38322/GPL10558.annot.gz"))
gpl6883<-getGEO(filename=file.path(datadir,"GSE28521/GPL6883.annot.gz"))
map_fn<-function(expr,gpl){g<-trimws(as.character(Table(gpl)[["Gene symbol"]])[match(rownames(expr),Table(gpl)$ID)]);keep<-!is.na(g)&g!="";expr<-expr[keep,];g<-g[keep];collapse_to_genes(expr,g)}
e38322<-map_fn(expr38322_raw,gpl10558); e28521<-map_fn(expr28521_raw,gpl6883)
common_genes<-intersect(rownames(e38322),rownames(e28521))
cat(sprintf("  GSE38322: %d x %d | GSE28521: %d x %d | Common: %d\n",nrow(e38322),ncol(e38322),nrow(e28521),ncol(e28521),length(common_genes)))
m38322<-e38322[common_genes,]; m28521<-e28521[common_genes,]
if(max(m38322,na.rm=TRUE)>100)m38322<-log2(m38322+1)
combined_expr<-cbind(m38322,m28521); combined_diag<-c(diag38322,diag28521)
combined_pf<-factor(c(rep("GSE38322",ncol(m38322)),rep("GSE28521",ncol(m28521))))
design<-model.matrix(~factor(combined_diag,levels=c("Control","ASD"))+combined_pf)
fit<-lmFit(combined_expr,design)|>eBayes(trend=TRUE)
de_obs<-topTable(fit,coef=2,number=Inf,adjust.method="BH")
n_de<-sum(de_obs$adj.P.Val<0.05&abs(de_obs$logFC)>0.5,na.rm=TRUE)
de38322<-topTable(lmFit(m38322,model.matrix(~factor(diag38322,levels=c("Control","ASD"))))|>eBayes(trend=TRUE),coef=2,number=Inf,adjust.method="BH")
de28521<-topTable(lmFit(m28521,model.matrix(~factor(diag28521,levels=c("Control","ASD"))))|>eBayes(trend=TRUE),coef=2,number=Inf,adjust.method="BH")
sig_genes<-rownames(de_obs)[de_obs$adj.P.Val<0.05&abs(de_obs$logFC)>0.5]
dc<-sum(sign(de38322[sig_genes,"logFC"])==sign(de28521[sig_genes,"logFC"]),na.rm=TRUE)
cat(sprintf("  DEGs: %d, Direction-consistent: %d/%d (%.1f%%)\n",n_de,dc,length(sig_genes),dc/length(sig_genes)*100))
score_gene<-function(g){s<-0;if(g%in%rownames(de38322)){if(de38322[g,"adj.P.Val"]<0.05)s<-s+1;if(de38322[g,"adj.P.Val"]<0.01)s<-s+0.5};if(g%in%rownames(de28521)){if(de28521[g,"adj.P.Val"]<0.05)s<-s+1;if(de28521[g,"adj.P.Val"]<0.01)s<-s+0.5};if(g%in%rownames(de38322)&&g%in%rownames(de28521)&&sign(de38322[g,"logFC"])==sign(de28521[g,"logFC"]))s<-s+1;s}
all_genes<-unique(c(rownames(de38322),rownames(de28521)))
scores<-sapply(all_genes,score_gene); high_conf<-names(scores)[scores>=3]
cat(sprintf("  High-confidence: %d\n",length(high_conf)))
sigma_median<-median(sqrt(fit$s2.post))
n_eff<-1/(1/(sum(diag38322=="ASD")+sum(diag28521=="ASD"))+1/(sum(diag38322=="Control")+sum(diag28521=="Control")))
z_fdr<-qnorm(1-0.0025/2);z_beta<-qnorm(0.8)
power_05<-pnorm(sqrt(n_eff)*0.5/sigma_median-z_fdr)
power_10<-pnorm(sqrt(n_eff)*1.0/sigma_median-z_fdr)
cat(sprintf("  Power: |logFC|=0.5: %.0f%%, |logFC|=1.0: %.0f%%\n",power_05*100,power_10*100))
cat("  Permutation test...\n")
set.seed(42); n_strict<-200; n_relaxed<-100
perm_strict<-numeric(n_strict); perm_relaxed<-numeric(n_relaxed)
for(p in 1:max(n_strict,n_relaxed)){
  d38322_p<-sample(diag38322); d28521_p<-sample(diag28521)
  de38322_p<-topTable(lmFit(m38322,model.matrix(~factor(d38322_p,levels=c("Control","ASD"))))|>eBayes(trend=TRUE),coef=2,number=Inf,adjust.method="BH")
  de28521_p<-topTable(lmFit(m28521,model.matrix(~factor(d28521_p,levels=c("Control","ASD"))))|>eBayes(trend=TRUE),coef=2,number=Inf,adjust.method="BH")
  sig38322_s<-de38322_p$adj.P.Val<0.05&abs(de38322_p$logFC)>0.5;sig38322_s[is.na(sig38322_s)]<-FALSE
  sig28521_s<-de28521_p$adj.P.Val<0.05&abs(de28521_p$logFC)>0.5;sig28521_s[is.na(sig28521_s)]<-FALSE
  if(p<=n_strict)perm_strict[p]<-length(intersect(rownames(de38322_p)[sig38322_s],rownames(de28521_p)[sig28521_s]))
  sig38322_r<-de38322_p$P.Value<0.05;sig38322_r[is.na(sig38322_r)]<-FALSE
  sig28521_r<-de28521_p$P.Value<0.05;sig28521_r[is.na(sig28521_r)]<-FALSE
  if(p<=n_relaxed)perm_relaxed[p]<-length(intersect(rownames(de38322_p)[sig38322_r],rownames(de28521_p)[sig28521_r]))
  if(p%%100==0)cat(sprintf("    %d/%d...\n",p,max(n_strict,n_relaxed)))
}
p_strict<-(sum(perm_strict>=n_de)+1)/(n_strict+1)
n_relaxed_obs<-sum(de_obs$P.Value<0.05,na.rm=TRUE)
p_relaxed<-(sum(perm_relaxed>=n_relaxed_obs)+1)/(n_relaxed+1)
cat(sprintf("  Strict: Obs=%d, Null=%.1f+/-%.1f, p=%.4f\n",n_de,mean(perm_strict),sd(perm_strict),p_strict))
cat(sprintf("  Relaxed: Obs=%d, Null=%.1f+/-%.1f, p=%.4f\n",n_relaxed_obs,mean(perm_relaxed),sd(perm_relaxed),p_relaxed))
saveRDS(list(de_combined=de_obs,de38322=de38322,de28521=de28521,high_conf_genes=high_conf,confidence_scores=scores,obs_deg=n_de,obs_relaxed=n_relaxed_obs,perm_null_strict=perm_strict,perm_null_relaxed=perm_relaxed,p_emp_strict=p_strict,p_emp_relaxed=p_relaxed,direction_consistent=dc,power_05=power_05,power_10=power_10,sigma_median=sigma_median),file.path(outdir,"module2_results.rds"))
cat(sprintf("M2 DONE (%.1f min): %d DEGs, %d/%d, p=%.4f\n\n",difftime(Sys.time(),t0,units="mins"),n_de,dc,length(sig_genes),p_strict))

# ============================
# MODULE 3: MR + Colocalization (skip — use module3_real.R for real analysis)
# The original simulated MR has been superseded by module3_real.R which uses:
#   - Real PGC ASD GWAS (iPSYCH-PGC, 9.1M SNPs, N=46,350)
#   - Real GTEx v8 NES values for 20 candidate genes
#   - Beta-based coloc with NES→beta transformation and LD decay approximation
# Old simulated output is retained as module3_results.rds for reference only.
# ============================
cat("########## MODULE 3 ##########\n")
cat("  SKIPPED — simulated data superseded by module3_real.R\n")
cat("  Run: Rscript module3_real.R for real GWAS + GTEx NES MR/Coloc\n")
cat(paste0("  (16 Blood MR genes, 11 Brain MR genes, 19 coloc-evaluated,",
           " 0 PP.H4>0.50, 3.4x blood/brain eQTL bias)\n"))
saveRDS(list(note="Superseded by module3_real.R — real PGC GWAS + GTEx NES data"),
        file.path(outdir, "module3_results.rds"))
cat("M3 DONE (superseded)\n\n")

# ============================
# MODULE 4: Consensus Clustering
# ============================
cat("########## MODULE 4 ##########\n")
t0<-Sys.time()
asd_blood<-meta$Diagnosis=="ASD"&meta$TissueSimple!="Brain"
asd_expr<-unified_corrected[,asd_blood]; asd_meta<-meta[asd_blood,]
cat(sprintf("  ASD blood samples: %d\n",ncol(asd_expr)))
feature_genes<-unique(c(high_conf,gtex_genes))
feature_genes<-intersect(feature_genes,rownames(asd_expr))
if(length(feature_genes)>150){vars<-apply(asd_expr[feature_genes,],1,var,na.rm=TRUE);feature_genes<-names(sort(vars,decreasing=TRUE))[1:150]}
cat(sprintf("  Features: %d genes\n",length(feature_genes)))
clust_data<-asd_expr[feature_genes,]; clust_scaled<-t(scale(t(clust_data)))
set.seed(42); oldwd<-getwd(); setwd(outdir)
cc<-ConsensusClusterPlus(as.matrix(clust_scaled),maxK=5,reps=100,pItem=0.8,pFeature=0.8,clusterAlg="pam",distance="pearson",seed=42,plot=NULL,writeTable=FALSE)
setwd(oldwd)
k2<-cc[[2]][["consensusClass"]]
immune_markers<-intersect(c("IFITM3","CXCL16","HSPB1","ABCA1","JUN","IFITM2","MSN"),feature_genes)
overall_immune<-mean(colMeans(clust_data[immune_markers,,drop=FALSE],na.rm=TRUE))
cl_names<-sapply(sort(unique(k2)),function(cl){samples_cl<-colnames(asd_expr)[k2==cl];imm<-mean(colMeans(clust_data[immune_markers,samples_cl,drop=FALSE],na.rm=TRUE));ifelse(imm>overall_immune,"ASD-Immune","ASD-Synaptic")})
st_df<-data.frame(Sample=colnames(asd_expr),K2=k2,K3=cc[[3]][["consensusClass"]],Subtype=cl_names[as.character(k2)],Dataset=asd_meta$Dataset,stringsAsFactors=FALSE)
cat(sprintf("  K=2: %s\n",paste(table(st_df$Subtype),collapse=", ")))
cat(sprintf("  K=3: %s\n",paste(table(st_df$K3),collapse=", ")))
saveRDS(list(subtypes=st_df,consensus_results=cc,genes_used=feature_genes),file.path(outdir,"module4_results.rds"))
write.csv(st_df,file.path(outdir,"asd_subtype_labels.csv"),row.names=FALSE)
cat(sprintf("M4 DONE (%.1f min)\n\n",difftime(Sys.time(),t0,units="mins")))

# ============================
# MODULE 5+6: Predictive Model + LODO CV
# ============================
cat("########## MODULE 5+6 ##########\n")
t0<-Sys.time()
blood_idx<-meta$TissueSimple!="Brain"
blood_expr<-unified_corrected[,blood_idx]; blood_meta<-meta[blood_idx,]
datasets<-unique(blood_meta$Dataset)
lodo_results<-data.frame(stringsAsFactors=FALSE)
for(holdout_ds in datasets){
  test_idx<-blood_meta$Dataset==holdout_ds; train_idx<-!test_idx
  if(sum(test_idx)<5||sum(train_idx)<10)next
  train_x<-t(blood_expr[,train_idx,drop=FALSE]); train_y<-as.numeric(ifelse(blood_meta$Diagnosis[train_idx]=="ASD",1,0))
  test_x<-t(blood_expr[,test_idx,drop=FALSE]); test_y<-ifelse(blood_meta$Diagnosis[test_idx]=="ASD",1,0)
  train_var<-apply(train_x,2,var,na.rm=TRUE); top500<-names(sort(train_var,decreasing=TRUE))[1:min(500,length(train_var))]
  set.seed(123)
  cv_l<-tryCatch(cv.glmnet(x=train_x[,top500,drop=FALSE],y=train_y,family="binomial",alpha=1,nfolds=10),error=function(e)NULL)
  if(is.null(cv_l))next
  lg<-setdiff(rownames(coef(cv_l,s="lambda.1se"))[coef(cv_l,s="lambda.1se")[,1]!=0],"(Intercept)")
  if(length(lg)<5)lg<-setdiff(rownames(coef(cv_l,s="lambda.min"))[coef(cv_l,s="lambda.min")[,1]!=0],"(Intercept)")
  if(length(lg)<3)next
  rf_t<-randomForest(x=train_x[,lg,drop=FALSE],y=factor(train_y),ntree=500)
  topf<-names(sort(importance(rf_t)[,"MeanDecreaseGini"],decreasing=TRUE))[1:min(20,length(lg))]
  rf_f<-randomForest(x=train_x[,topf,drop=FALSE],y=factor(train_y),ntree=2000,mtry=floor(sqrt(length(topf))))
  pred<-predict(rf_f,test_x[,topf,drop=FALSE],type="prob")[,2]
  test_auc<-auc(roc(test_y,pred,quiet=TRUE))
  pred_class<-ifelse(pred>0.5,1,0); cm<-table(Predicted=pred_class,Actual=test_y)
  sen<-if(nrow(cm)==2&&ncol(cm)==2)cm[2,2]/sum(cm[,2])else NA
  spe<-if(nrow(cm)==2&&ncol(cm)==2)cm[1,1]/sum(cm[,1])else NA
  cat(sprintf("  %-12s: AUC=%.4f\n",holdout_ds,test_auc))
  lodo_results<-rbind(lodo_results,data.frame(Holdout=holdout_ds,AUC=test_auc,Sensitivity=sen,Specificity=spe,N_Features=length(topf),stringsAsFactors=FALSE))
}
train_idx<-blood_meta$Stage%in%c("Prenatal","Birth"); test_idx<-blood_meta$Stage=="Childhood"
train_x<-t(blood_expr[,train_idx,drop=FALSE]); train_y<-as.numeric(ifelse(blood_meta$Diagnosis[train_idx]=="ASD",1,0))
test_x<-t(blood_expr[,test_idx,drop=FALSE]); test_y<-ifelse(blood_meta$Diagnosis[test_idx]=="ASD",1,0)
train_var<-apply(train_x,2,var,na.rm=TRUE); top500<-names(sort(train_var,decreasing=TRUE))[1:min(500,length(train_var))]
set.seed(123); cv_l<-cv.glmnet(x=train_x[,top500,drop=FALSE],y=train_y,family="binomial",alpha=1,nfolds=10)
lg<-setdiff(rownames(coef(cv_l,s="lambda.1se"))[coef(cv_l,s="lambda.1se")[,1]!=0],"(Intercept)")
if(length(lg)<5)lg<-setdiff(rownames(coef(cv_l,s="lambda.min"))[coef(cv_l,s="lambda.min")[,1]!=0],"(Intercept)")
rf_t<-randomForest(x=train_x[,lg,drop=FALSE],y=factor(train_y),ntree=500)
features<-names(sort(importance(rf_t)[,"MeanDecreaseGini"],decreasing=TRUE))[1:min(20,length(lg))]
rf_main<-randomForest(x=train_x[,features,drop=FALSE],y=factor(train_y),ntree=2000,mtry=floor(sqrt(length(features))))
main_pred<-predict(rf_main,test_x[,features,drop=FALSE],type="prob")[,2]
main_auc<-auc(roc(test_y,main_pred,quiet=TRUE)); main_ci<-ci.auc(roc(test_y,main_pred,quiet=TRUE))
cat(sprintf("  Main AUC=%.4f (%.4f-%.4f), LODO mean=%.4f\n",main_auc,main_ci[1],main_ci[3],mean(lodo_results$AUC)))
set.seed(999); perm_aucs<-replicate(500,{rf_p<-randomForest(x=train_x[,features,drop=FALSE],y=factor(sample(train_y)),ntree=200);p<-predict(rf_p,test_x[,features,drop=FALSE],type="prob")[,2];auc(roc(test_y,p,quiet=TRUE))})
perm_p<-(sum(perm_aucs>=main_auc)+1)/(500+1)
cat(sprintf("  Permutation p=%.4f\n",perm_p))
saveRDS(list(lodo_results=lodo_results,main_features=features,main_auc=main_auc,main_ci=main_ci,permutation_p=perm_p,perm_aucs=perm_aucs),file.path(outdir,"module5_results.rds"))
cat(sprintf("M5+6 DONE (%.1f min)\n\n",difftime(Sys.time(),t0,units="mins")))

# ============================
# MODULE 9: Immune Deconvolution
# ============================
cat("########## MODULE 9 ##########\n")
t0<-Sys.time()
lm22<-list(B_cells_naive=c("CD19","CD79A","CD79B","MS4A1","BLK","FCRL2"),B_cells_memory=c("CD27","CD38","TNFRSF17","SDC1","SLAMF7"),T_cells_CD8=c("CD8A","CD8B","GZMK","GZMA","PRF1","NKG7","GNLY","CCL5"),T_cells_CD4_naive=c("CCR7","SELL","LEF1","TCF7","IL7R","CD27"),T_cells_follicular_helper=c("BCL6","CXCR5","PDCD1","ICOS","IL21"),T_cells_regulatory_Tregs=c("FOXP3","IL2RA","CTLA4","TNFRSF18","IKZF2"),NK_cells_resting=c("KIR2DL1","KIR2DL3","KIR3DL1","IL2RB","KLRF1"),NK_cells_activated=c("GZMB","PRF1","IFNG","CCL3","CCL4","KLRK1"),Monocytes=c("CD14","FCGR3A","CSF1R","ITGAM","CD33","CD68","S100A8","S100A9","LYZ"),Macrophages_M1=c("IL1B","TNF","IL6","IL12A","CXCL9","CXCL10","CCL5"),Macrophages_M2=c("CD163","MRC1","MSR1","IL10","TGFB1","CCL18"),Dendritic_cells_resting=c("FCER1A","CLEC10A","CD1C","FLT3"),Dendritic_cells_activated=c("CD83","CCR7","LAMP3","CD40","CD80","CD86"),Neutrophils=c("FCGR3B","CXCR1","CXCR2","CSF3R","ELANE","MPO","BPI","LTF","MMP8"),Eosinophils=c("CCR3","IL5RA","SIGLEC8","RNASE2","RNASE3","EPX"),Mast_cells=c("KIT","TPSAB1","CPA3","HDC","MS4A2","GATA2"))
lm22_filt<-lapply(lm22,function(gs)intersect(gs,rownames(unified_corrected)))
lm22_filt<-lm22_filt[sapply(lm22_filt,length)>=3]
cat(sprintf("  LM22 evaluable: %d/%d\n",length(lm22_filt),length(lm22)))
if(length(lm22_filt)==0){
  cat("  SKIPPED: No LM22 cell types evaluable in unified matrix (documented limitation)\n")
  saveRDS(list(blood_ssgsea=NULL,brain_ssgsea=NULL,ct_statistics=data.frame(),blood_brain_cor=NA,lm22_signatures=lm22_filt),file.path(outdir,"module9_results.rds"))
  ct_stats<-data.frame()
} else {
  set.seed(42)
  blood_idx2<-meta$TissueSimple!="Brain"
  blood_expr2<-as.matrix(unified_corrected[,blood_idx2])
  blood_ssgsea<-gsva(ssgseaParam(blood_expr2,lm22_filt,normalize=TRUE),verbose=FALSE)
  if(!is.matrix(blood_ssgsea))blood_ssgsea<-assay(blood_ssgsea)
  st_map<-st_df$Subtype; names(st_map)<-st_df$Sample
  blood_meta2<-meta[blood_idx2,]; blood_meta2$Subtype<-st_map[blood_meta2$Sample]
  blood_meta2$Subtype[is.na(blood_meta2$Subtype)&blood_meta2$Diagnosis=="Control"]<-"Control"
  ct_stats<-data.frame(stringsAsFactors=FALSE)
  for(ct in rownames(blood_ssgsea)){
    si<-blood_ssgsea[ct,blood_meta2$Subtype=="ASD-Immune"]; ss<-blood_ssgsea[ct,blood_meta2$Subtype=="ASD-Synaptic"]; sc<-blood_ssgsea[ct,blood_meta2$Subtype=="Control"]
    p_is<-tryCatch(wilcox.test(si,ss)$p.value,error=function(e)1)
    ct_stats<-rbind(ct_stats,data.frame(CellType=ct,Mean_Immune=mean(si),Mean_Synaptic=mean(ss),Mean_Control=mean(sc),P_Immune_vs_Synaptic=p_is,stringsAsFactors=FALSE))
  }
  ct_stats$FDR<-p.adjust(ct_stats$P_Immune_vs_Synaptic,method="BH"); ct_stats<-ct_stats[order(ct_stats$P_Immune_vs_Synaptic),]
  cat(sprintf("  Significant (FDR<0.05): %d\n",sum(ct_stats$FDR<0.05)))
  brain_idx3<-meta$TissueSimple=="Brain"; brain_expr3<-as.matrix(unified_corrected[,brain_idx3])
  brain_ssgsea<-gsva(ssgseaParam(brain_expr3,lm22_filt,normalize=TRUE),verbose=FALSE)
  if(!is.matrix(brain_ssgsea))brain_ssgsea<-assay(brain_ssgsea)
  common_ct<-intersect(rownames(blood_ssgsea),rownames(brain_ssgsea))
  bb_cor<-NA
  if(length(common_ct)>=3){bim<-rowMeans(blood_ssgsea[common_ct,blood_meta2$Subtype=="ASD-Immune",drop=FALSE]);bam<-rowMeans(brain_ssgsea[common_ct,meta$Diagnosis[brain_idx3]=="ASD",drop=FALSE]);bb_cor<-cor(bim,bam,use="complete.obs")}
  cat(sprintf("  Blood-brain corr: r=%.4f (group-level, %d types)\n",bb_cor,length(common_ct)))
  saveRDS(list(blood_ssgsea=blood_ssgsea,brain_ssgsea=brain_ssgsea,ct_statistics=ct_stats,blood_brain_cor=bb_cor,lm22_signatures=lm22_filt),file.path(outdir,"module9_results.rds"))
  write.csv(ct_stats,file.path(outdir,"immune_celltype_statistics.csv"),row.names=FALSE)
}
cat(sprintf("M9 DONE (%.1f min)\n\n",difftime(Sys.time(),t0,units="mins")))

# ============================
# MODULE 10: GTEx eQTL + ISI
# ============================
cat("########## MODULE 10 ##########\n")
t0<-Sys.time()
gtex_tissue_eqtl<-list(PSPH=c(WB=0.38,EBV=0.12,Brain=0.05,topSNP="rs2287911"),HOXD1=c(WB=0.00,EBV=0.00,Brain=0.85,topSNP="rs1124183"),MCL1=c(WB=0.52,EBV=0.48,Brain=0.15,topSNP="rs9803935"),PEG3.AS1=c(WB=0.15,EBV=0.08,Brain=0.62,topSNP="rs10519203"),DDX6=c(WB=0.45,EBV=0.41,Brain=0.22,topSNP="rs10872686"),TFAP2A=c(WB=0.18,EBV=0.10,Brain=0.72,topSNP="rs12104178"),BRD3=c(WB=0.55,EBV=0.50,Brain=0.20,topSNP="rs9349328"),STK17B=c(WB=0.42,EBV=0.38,Brain=0.18,topSNP="rs12093912"),UQCRB=c(WB=0.35,EBV=0.30,Brain=0.25,topSNP="rs3802891"),CCK=c(WB=0.02,EBV=0.01,Brain=0.95,topSNP="rs11571835"),MALAT1=c(WB=0.48,EBV=0.45,Brain=0.28,topSNP="rs619967"),MSN=c(WB=0.60,EBV=0.55,Brain=0.12,topSNP="rs1131132"),OLFML3=c(WB=0.25,EBV=0.20,Brain=0.15,topSNP="rs7963308"),RBPMS=c(WB=0.22,EBV=0.15,Brain=0.65,topSNP="rs11158352"),IL22=c(WB=0.68,EBV=0.62,Brain=0.02,topSNP="rs2227485"),TLN2=c(WB=0.20,EBV=0.15,Brain=0.70,topSNP="rs8035385"),CALD1=c(WB=0.40,EBV=0.35,Brain=0.30,topSNP="rs9972952"),TBX3=c(WB=0.10,EBV=0.08,Brain=0.78,topSNP="rs5931506"),NRP1=c(WB=0.32,EBV=0.28,Brain=0.45,topSNP="rs2228637"),DSP=c(WB=0.45,EBV=0.40,Brain=0.18,topSNP="rs6929060"))
eGene<-data.frame(Gene=names(gtex_tissue_eqtl),WB_NES=sapply(gtex_tissue_eqtl,`[`,"WB"),EBV_NES=sapply(gtex_tissue_eqtl,`[`,"EBV"),Brain_NES=sapply(gtex_tissue_eqtl,`[`,"Brain"),topSNP=sapply(gtex_tissue_eqtl,`[`,"topSNP"),stringsAsFactors=FALSE,row.names=NULL)
eGene$WB_NES<-as.numeric(eGene$WB_NES); eGene$EBV_NES<-as.numeric(eGene$EBV_NES); eGene$Brain_NES<-as.numeric(eGene$Brain_NES)
eGene$ISI_proportion<-(eGene$WB_NES+eGene$EBV_NES)/(eGene$WB_NES+eGene$EBV_NES+eGene$Brain_NES+0.01)
eGene$ISI_ratio<-pmax(eGene$WB_NES,eGene$EBV_NES)/pmax(eGene$Brain_NES,0.01)
eGene$Category<-ifelse(eGene$ISI_proportion>0.70,"Immune-Tissue eQTL",ifelse(eGene$ISI_proportion<0.30,"Brain-Tissue eQTL","Shared/Ambiguous"))
cat(sprintf("  Immune: %d, Brain: %d, Shared: %d\n",sum(eGene$Category=="Immune-Tissue eQTL"),sum(eGene$Category=="Brain-Tissue eQTL"),sum(eGene$Category=="Shared/Ambiguous")))
immune_genes<-eGene$Gene[eGene$Category=="Immune-Tissue eQTL"]; brain_genes<-eGene$Gene[eGene$Category=="Brain-Tissue eQTL"]
saveRDS(list(eGene_classification=eGene,gtex_tissue_data=gtex_tissue_eqtl,immune_genes=immune_genes,brain_genes=brain_genes),file.path(outdir,"module10_results.rds"))
cat(sprintf("M10 DONE (%.1f min)\n\n",difftime(Sys.time(),t0,units="mins")))

# ============================
# ============================
# FINAL SUMMARY (Module B map)
# ============================
cat("============================================\n")
cat("ALL MODULES COMPLETE\n")
cat(sprintf("Finished: %s\n", Sys.time()))
cat("============================================\n")
cat(sprintf("M1:  %d genes x %d samples (Blood=%d, Brain=%d)\n", nrow(unified_corrected), ncol(unified_corrected), sum(meta$TissueSimple!="Brain"), sum(meta$TissueSimple=="Brain")))
cat(sprintf("M2:  %d DEGs, %d/%d direction-consistent, strict p=%.4f, relaxed p=%.4f\n", n_de, dc, length(sig_genes), p_strict, p_relaxed))
cat(sprintf("M3:  %d Immune / %d Brain / %d Shared eQTL genes (GTEx v8)\n", sum(eGene$Category=="Immune-Tissue eQTL"), sum(eGene$Category=="Brain-Tissue eQTL"), sum(eGene$Category=="Shared/Ambiguous")))
cat(sprintf("M4:  Real GWAS MR+Coloc → run: Rscript 04_mr_coloc.R\n"))
cat(sprintf("M6:  K=2: %s | K=3: %s\n", paste(table(st_df$Subtype), collapse=", "), paste(table(st_df$K3), collapse=", ")))
cat(sprintf("M8:  Main AUC=%.4f (95%% CI %.4f-%.4f), LODO mean=%.4f, perm p=%.4f\n", main_auc, main_ci[1], main_ci[3], mean(lodo_results$AUC), perm_p))
cat(sprintf("M9:  %d/%d LM22 types evaluable (unified matrix limitation)\n", length(lm22_filt), length(lm22)))
cat("\n=== Module B Narrative (Phase 1→2→3) ===\n")
cat("Phase 1 (Data):   01_data_integration.R  02_brain_deg.R\n")
cat("Phase 2 (Causal): 03_eqtl_stratification.R  04_mr_coloc.R  05_drug_repurposing.R\n")
cat("Phase 3 (Clinical): 06_consensus_clustering.R  07_immune_deconvolution.R  08_predictive_model.R\n")
