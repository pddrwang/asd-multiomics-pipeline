# ============================================================================
# Module 11: Drug Repurposing — DEG-to-Drug Mapping with SFARI Filtering
# Expanded drug-gene database (110+ drug-gene pairs)
# ============================================================================
suppressMessages({library(dplyr); library(data.table)})

# Auto-detect project root
if (!requireNamespace("rstudioapi", quietly = TRUE)) install.packages("rstudioapi", repos = "https://cloud.r-project.org")
script_path <- tryCatch(rstudioapi::getActiveDocumentContext()$path, error = function(e) "")
if (script_path == "" || is.null(script_path)) {
  args <- commandArgs(trailingOnly = FALSE)
  fa <- grep("^--file=", args, value = TRUE)
  script_path <- if (length(fa) > 0) normalizePath(sub("^--file=", "", fa)) else normalizePath(".")
}
workdir <- normalizePath(dirname(script_path))
for (i in 1:5) {
  if (file.exists(file.path(workdir, "03_原始数据"))) break
  workdir <- dirname(workdir)
}
outdir  <- file.path(workdir, "分析结果")
cat("===== Module 11: Drug Repurposing =====\n\n")

# Load inputs
mod2  <- readRDS(file.path(outdir, "module2_results.rds"))
mod3r <- readRDS(file.path(outdir, "module3_real_results.rds"))
de_genes <- rownames(mod2$de_combined)[mod2$de_combined$adj.P.Val < 0.05 & abs(mod2$de_combined$logFC) > 0.5]
hc_genes <- mod2$high_conf_genes
mr_all  <- mod3r$mr_results[mod3r$mr_results$F_stat > 10 & mod3r$mr_results$MR_pval < 0.05, ]

# SFARI gene lists
sfari_s1 <- c("ADNP","ANK2","ARID1B","ASH1L","BCL11A","CHD2","CHD8","CTNNB1","CUL3","DEAF1","DNMT3A","DSCAM","DSG2","DYRK1A","FMR1","FOXP1","GIGYF1","GRIN2B","KDM5B","KMT2A","KMT2C","KMT5B","MBD5","MECP2","MED13","MEF2C","MYT1L","NACC1","NAV2","NIPBL","NRXN1","NSD1","PAX5","PHF2","POGZ","PTEN","REST","SCN2A","SETD5","SHANK3","SIN3A","SLC6A1","SMARCC2","STXBP1","SUV420H1","SYNGAP1","TAF1","TBL1XR1","TCF4","TET3","TLK2","TRIP12","TRIO","UBR1","WAC","ZBTB20","ZNF292","ZNF462","ZNF536")
sfari_all <- c(sfari_s1,"ABCA2","ACMSD","AGAP1","ANKRD11","AP2M1","BAZ2B","BCL11B","BRSK2","CACNA1E","CACNA2D3","CNOT3","CNTN4","CUX1","DLGAP2","DMD","DPP10","ETFB","GRID2","HIVEP2","HIVEP3","INTS6","KATNAL2","KDM6B","MACROD2","MAPK8IP2","MBOAT7","MIB1","MYO10","NCKAP1","NLGN3","OTUD7A","PCDH9","PDE4D","PEX7","PHF21A","PPP2R5D","RANBP17","RIMS1","SEMA5A","SHANK2","SLC38A10","SPAST","SRCAP","SYN1","TAOK2","TNRC6B","UPF2","USP45","WDFY3")

# Drug-Gene database (curated DrugBank + CTD + ClinicalTrials)
drug_db <- rbind(
  # Immune/inflammatory
  data.frame(Gene="JUN", Drug="Methotrexate", FDA="Approved", Indication="RA/NF-kB pathway", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="JUN", Drug="Sulfasalazine", FDA="Approved", Indication="RA/IBD anti-inflammatory", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="JUN", Drug="Prednisolone", FDA="Approved", Indication="Corticosteroid/immunosuppression", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="JUN", Drug="Tofacitinib", FDA="Approved", Indication="JAK inhibitor/RA", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="JUN", Drug="Curcumin", FDA="Investigational", Indication="NF-kB inhibitor/antioxidant", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="HSPB1", Drug="Quercetin", FDA="Dietary supplement", Indication="Antioxidant/neuroprotection", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="HSPB1", Drug="Resveratrol", FDA="Dietary supplement", Indication="SIRT1/neuroprotection", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="HSPB1", Drug="N-acetylcysteine", FDA="Approved", Indication="Glutathione/antioxidant", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="IFITM3", Drug="Interferon beta-1a", FDA="Approved", Indication="MS/antiviral", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="IFITM2", Drug="Interferon alfa-2b", FDA="Approved", Indication="Antiviral/immunomodulator", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="CXCL16", Drug="Etanercept", FDA="Approved", Indication="TNF inhibitor/RA", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="CXCL16", Drug="Adalimumab", FDA="Approved", Indication="TNF inhibitor/autoimmune", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="CXCL16", Drug="Infliximab", FDA="Approved", Indication="TNF inhibitor/IBD", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="MSN", Drug="Dexamethasone", FDA="Approved", Indication="Corticosteroid/anti-inflammatory", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="MCL1", Drug="Venetoclax", FDA="Approved", Indication="BCL-2 inhibitor/CLL", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="IL22", Drug="Ustekinumab", FDA="Approved", Indication="IL-12/23 inhibitor", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="ABCA1", Drug="Probucol", FDA="Approved", Indication="Lipid-lowering/antioxidant", Source="CTD", stringsAsFactors=FALSE),

  # SFARI high-confidence targets
  data.frame(Gene="TCF4", Drug="Lithium", FDA="Approved", Indication="Neurogenesis/mood stabilizer", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="TCF4", Drug="Valproic acid", FDA="Approved", Indication="HDAC inhibitor/epilepsy", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="MEF2C", Drug="Vorinostat", FDA="Approved", Indication="HDAC inhibitor/CTCL", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="MEF2C", Drug="Lithium", FDA="Approved", Indication="Neurogenesis/mood stabilizer", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="MEF2C", Drug="Fluoxetine", FDA="Approved", Indication="SSRI/depression", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="REST", Drug="Valproic acid", FDA="Approved", Indication="HDAC inhibitor/epilepsy", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="REST", Drug="Carbamazepine", FDA="Approved", Indication="Na+ channel/epilepsy", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="GRIN2B", Drug="Memantine", FDA="Approved", Indication="NMDAR antagonist/Alzheimer", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="GRIN2B", Drug="Ketamine", FDA="Approved", Indication="NMDAR antagonist/anesthesia", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="GRIN2B", Drug="Amantadine", FDA="Approved", Indication="NMDAR antagonist/Parkinson", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="SCN2A", Drug="Lamotrigine", FDA="Approved", Indication="Na+ channel/epilepsy", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="SCN2A", Drug="Carbamazepine", FDA="Approved", Indication="Na+ channel/epilepsy", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="SCN2A", Drug="Phenytoin", FDA="Approved", Indication="Na+ channel/epilepsy", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="SCN2A", Drug="Lacosamide", FDA="Approved", Indication="Na+ channel/epilepsy", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="SYNGAP1", Drug="Rapastinel", FDA="Investigational", Indication="NMDAR PAM/cognitive", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="SHANK3", Drug="IGF-1 (Mecasermin)", FDA="Approved", Indication="Neurotrophic/growth", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="SHANK3", Drug="Baclofen", FDA="Approved", Indication="GABA-B agonist/spasticity", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="PTEN", Drug="Sirolimus", FDA="Approved", Indication="mTOR inhibitor/TSC", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="PTEN", Drug="Everolimus", FDA="Approved", Indication="mTOR inhibitor/TSC-ASD", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="PTEN", Drug="Metformin", FDA="Approved", Indication="AMPK activator/diabetes", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="FMR1", Drug="Trofinetide", FDA="Approved", Indication="Rett syndrome/GFAP", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="FMR1", Drug="Mavoglurant", FDA="Investigational", Indication="mGluR5 antagonist/Fragile X", Source="ClinicalTrials", stringsAsFactors=FALSE),
  data.frame(Gene="DYRK1A", Drug="Epigallocatechin gallate", FDA="Dietary supplement", Indication="DYRK1A inhibitor/green tea", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="CHD8", Drug="Vorinostat", FDA="Approved", Indication="HDAC inhibitor/epigenetic", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="ARID1B", Drug="Tazemetostat", FDA="Approved", Indication="EZH2 inhibitor/epigenetic", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="UBR1", Drug="Bortezomib", FDA="Approved", Indication="Proteasome inhibitor", Source="DrugBank", stringsAsFactors=FALSE),

  # Synaptic/neuronal
  data.frame(Gene="CCK", Drug="Pentagastrin", FDA="Approved", Indication="CCK-B agonist/diagnostic", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="TLN2", Drug="Cilengitide", FDA="Investigational", Indication="Integrin inhibitor/glioblastoma", Source="ClinicalTrials", stringsAsFactors=FALSE),
  data.frame(Gene="HOXD1", Drug="Tretinoin", FDA="Approved", Indication="Retinoic acid/APL", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="NRP1", Drug="Bevacizumab", FDA="Approved", Indication="VEGF/anti-angiogenic", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="TRIO", Drug="Fasudil", FDA="Approved", Indication="ROCK inhibitor/vasospasm", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="ANK2", Drug="Flecainide", FDA="Approved", Indication="Na+ channel/arrhythmia", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="CACNA1E", Drug="Gabapentin", FDA="Approved", Indication="Ca2+ channel/neuropathic pain", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="SLC6A1", Drug="Tiagabine", FDA="Approved", Indication="GAT-1 inhibitor/epilepsy", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="GABRB3", Drug="Bumetanide", FDA="Approved", Indication="NKCC1 inhibitor/ASD trials", Source="ClinicalTrials", stringsAsFactors=FALSE),
  data.frame(Gene="GABRB3", Drug="Clonazepam", FDA="Approved", Indication="GABA-A PAM/anxiety", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="OXTR", Drug="Oxytocin", FDA="Approved", Indication="Social behavior/ASD trials", Source="ClinicalTrials", stringsAsFactors=FALSE),
  data.frame(Gene="AVPR1A", Drug="Balovaptan", FDA="Investigational", Indication="V1a antagonist/ASD trials", Source="ClinicalTrials", stringsAsFactors=FALSE),

  # Mitochondrial/metabolic
  data.frame(Gene="UQCRB", Drug="Coenzyme Q10", FDA="Dietary supplement", Indication="Mitochondrial/ETC support", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="UQCRB", Drug="Idebenone", FDA="Approved", Indication="Mitochondrial/Leber hereditary", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="CALD1", Drug="Verapamil", FDA="Approved", Indication="Ca2+ channel/hypertension", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="DSP", Drug="N-acetylcysteine", FDA="Approved", Indication="Antioxidant/mucolytic", Source="CTD", stringsAsFactors=FALSE),

  # Folate/one-carbon metabolism
  data.frame(Gene="PSPH", Drug="Folinic acid", FDA="Approved", Indication="Folate/chemotherapy rescue", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="PSPH", Drug="Folic acid", FDA="Approved", Indication="Folate/neural tube", Source="DrugBank", stringsAsFactors=FALSE),

  # Epigenetic / transcription
  data.frame(Gene="BRD3", Drug="JQ1", FDA="Investigational", Indication="BET inhibitor/research", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="BRD3", Drug="Mivebresib", FDA="Investigational", Indication="BET inhibitor/oncology", Source="ClinicalTrials", stringsAsFactors=FALSE),
  data.frame(Gene="TFAP2A", Drug="Retinoic acid", FDA="Approved", Indication="AP-2 transcription/APL", Source="CTD", stringsAsFactors=FALSE),

  # ASD clinical trials
  data.frame(Gene="HTR2A", Drug="Risperidone", FDA="Approved", Indication="ASD irritability", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="HTR2A", Drug="Aripiprazole", FDA="Approved", Indication="ASD irritability", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="DRD2", Drug="Risperidone", FDA="Approved", Indication="ASD irritability", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="CYP19A1", Drug="Sulforaphane", FDA="Dietary supplement", Indication="NRF2 activator/ASD trials", Source="ClinicalTrials", stringsAsFactors=FALSE),
  data.frame(Gene="NRXN1", Drug="Clonazepam", FDA="Approved", Indication="GABA-A/anxiety", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="NLGN3", Drug="Baclofen", FDA="Approved", Indication="GABA-B/spasticity", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="SHANK2", Drug="Riluzole", FDA="Approved", Indication="Glutamate modulator/ALS", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="CNTNAP2", Drug="Bumetanide", FDA="Approved", Indication="NKCC1/ASD trials", Source="ClinicalTrials", stringsAsFactors=FALSE),
  data.frame(Gene="PDE4D", Drug="Apremilast", FDA="Approved", Indication="PDE4 inhibitor/psoriasis", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="DMD", Drug="Ataluren", FDA="Approved", Indication="Read-through/Duchenne", Source="DrugBank", stringsAsFactors=FALSE),

  # Neuroinflammation repurposing
  data.frame(Gene="IL6", Drug="Tocilizumab", FDA="Approved", Indication="IL-6R inhibitor/RA", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="IL1B", Drug="Anakinra", FDA="Approved", Indication="IL-1R antagonist/RA", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="NFKB1", Drug="Aspirin", FDA="Approved", Indication="NF-kB inhibitor/anti-inflammatory", Source="CTD", stringsAsFactors=FALSE),
  data.frame(Gene="STAT3", Drug="Ruxolitinib", FDA="Approved", Indication="JAK inhibitor/myelofibrosis", Source="DrugBank", stringsAsFactors=FALSE),
  data.frame(Gene="MTOR", Drug="Everolimus", FDA="Approved", Indication="mTOR inhibitor/TSC-ASD", Source="DrugBank", stringsAsFactors=FALSE)
)

# Classify matches by tier
target_genes <- unique(c(de_genes, hc_genes, mr_all$Gene))
tier1 <- drug_db[drug_db$Gene %in% c(de_genes, hc_genes), ]; tier1$Tier <- "1_DEG"
tier2 <- drug_db[drug_db$Gene %in% mr_all$Gene, ];              tier2$Tier <- "2_MR"
tier3 <- drug_db[drug_db$Gene %in% mod3r$isi_results$Gene[mod3r$isi_results$Category == "Brain-Tissue eQTL"], ]; tier3$Tier <- "3_Brain_eQTL"

drug_hits <- unique(rbind(tier1, tier2, tier3))
drug_hits$SFARI <- ifelse(drug_hits$Gene %in% sfari_s1, "Score 1-2 (High)",
                          ifelse(drug_hits$Gene %in% sfari_all, "Score 3 (Moderate)", "—"))
drug_hits <- drug_hits[order(drug_hits$SFARI != "—", drug_hits$FDA == "Approved", decreasing=TRUE), ]

# Summary
cat(sprintf("Drug-gene DB: %d entries\n", nrow(drug_db)))
cat(sprintf("Matches: %d (T1_DEG=%d T2_MR=%d T3_Brain=%d)\n\n", nrow(drug_hits), nrow(tier1), nrow(tier2), nrow(tier3)))

cat("FDA status:\n")
cat(sprintf("  Approved:        %d\n", sum(drug_hits$FDA == "Approved")))
cat(sprintf("  Investigational:  %d\n", sum(drug_hits$FDA == "Investigational")))
cat(sprintf("  Dietary:          %d\n\n", sum(grepl("Dietary", drug_hits$FDA))))

cat("SFARI support:\n")
cat(sprintf("  High-confidence:  %d\n", sum(grepl("1-2", drug_hits$SFARI))))
cat(sprintf("  Moderate:         %d\n", sum(grepl("3", drug_hits$SFARI))))

cat("\nTop candidates (FDA approved + SFARI):\n")
top <- drug_hits[drug_hits$FDA == "Approved" & grepl("High|Moderate", drug_hits$SFARI), ]
if (nrow(top) > 0) {
  for (j in 1:nrow(top)) cat(sprintf("  %-20s → %-25s (%s)\n", top$Gene[j], top$Drug[j], top$Indication[j]))
} else {
  cat("  (None — expected: most ASD drug targets lack direct FDA approval for ASD indications)\n")
}

# SFARI overlap
deg_sfari_s1 <- intersect(de_genes, sfari_s1)
cat(sprintf("\nSFARI overlap: %d DEGs in Score 1-2 / %d in any SFARI\n", length(deg_sfari_s1), length(intersect(de_genes, sfari_all))))

# Save
saveRDS(list(drug_hits=drug_hits, drug_db=drug_db, sfari=list(s1=sfari_s1, all=sfari_all)),
        file.path(outdir, "module11_drug_results.rds"))
write.csv(drug_hits, file.path(outdir, "drug_repurposing_candidates.csv"), row.names=FALSE)
cat(sprintf("\nModule 11 DONE — %d drug-gene matches saved\n", nrow(drug_hits)))
