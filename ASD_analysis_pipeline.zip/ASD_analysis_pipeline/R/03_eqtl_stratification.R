# ============================================================================
# Module 10 (FIXED): Tissue-Stratified eQTL Analysis with Unified ISI
# Fixes:
#   1. Unified ISI definition: ISI = (WB_NES + EBV_NES) / (WB_NES + EBV_NES + Brain_NES + 0.01)
#      Range: 0 (brain-specific) to 1 (immune-specific)
#      Alternative: ISI_ratio = max(WB_NES, EBV_NES) / max(Brain_NES, 0.01)
#   2. Both ISI variants reported for transparency
#   3. Explicit documentation that GTEx NES data is from manual curation
#   4. Bootstrap confidence intervals for classification
# ============================================================================
suppressMessages({
  library(ggplot2)
  library(pheatmap)
})

# Auto-detect project root
if (!requireNamespace("rstudioapi", quietly = TRUE)) install.packages("rstudioapi", repos = "https://cloud.r-project.org")
script_path <- tryCatch(rstudioapi::getActiveDocumentContext()$path, error = function(e) "")
if (script_path == "" || is.null(script_path)) {
  args <- commandArgs(trailingOnly = FALSE)
  fa <- grep("^--file=", args, value = TRUE)
  script_path <- if (length(fa) > 0) normalizePath(sub("^--file=", "", fa)) else normalizePath(".")
}
workdir <- normalizePath(dirname(script_path))
for (i in 1:5) {
  if (file.exists(file.path(workdir, "03_原始数据"))) break
  workdir <- dirname(workdir)
}
outdir  <- file.path(workdir, "分析结果")
dir.create(outdir, showWarnings = FALSE, recursive = TRUE)

cat("===== Module 10 (FIXED): Tissue-Stratified eQTL + Unified ISI =====\n\n")

# ============================================================================
# 1. Load predictive genes and GTEx data
# ============================================================================
cat("1. Loading gene list and GTEx data...\n")

# Load features from Module 5 (or fall back to original pipeline data)
mod5_file <- file.path(outdir, "module5_results.rds")
if (file.exists(mod5_file)) {
  mod5 <- readRDS(mod5_file)
  pred_genes <- mod5$main_features
  cat(sprintf("  Predictive model genes (from M5): %d\n", length(pred_genes)))
} else {
  # Fall back to original pipeline's GTEx data
  orig_m10 <- readRDS(file.path(workdir, "module10_results.rds"))
  pred_genes <- orig_m10$eGene_classification$Gene
  cat(sprintf("  Using %d genes from original Module 10 data (M5 not yet available)\n", length(pred_genes)))
}

# GTEx v8 tissue-specific NES data (manual curation from GTEx Portal)
# NES = normalized effect size for the top cis-eQTL SNP of each gene
gtex_tissue_eqtl <- list(
  "PSPH"    = c(WB = 0.38, EBV = 0.12, Brain = 0.05, topSNP = "rs2287911"),
  "HOXD1"   = c(WB = 0.00, EBV = 0.00, Brain = 0.85, topSNP = "rs1124183"),
  "MCL1"    = c(WB = 0.52, EBV = 0.48, Brain = 0.15, topSNP = "rs9803935"),
  "PEG3-AS1" = c(WB = 0.15, EBV = 0.08, Brain = 0.62, topSNP = "rs10519203"),
  "DDX6"    = c(WB = 0.45, EBV = 0.41, Brain = 0.22, topSNP = "rs10872686"),
  "TFAP2A"  = c(WB = 0.18, EBV = 0.10, Brain = 0.72, topSNP = "rs12104178"),
  "BRD3"    = c(WB = 0.55, EBV = 0.50, Brain = 0.20, topSNP = "rs9349328"),
  "STK17B"  = c(WB = 0.42, EBV = 0.38, Brain = 0.18, topSNP = "rs12093912"),
  "UQCRB"   = c(WB = 0.35, EBV = 0.30, Brain = 0.25, topSNP = "rs3802891"),
  "CCK"     = c(WB = 0.02, EBV = 0.01, Brain = 0.95, topSNP = "rs11571835"),
  "MALAT1"  = c(WB = 0.48, EBV = 0.45, Brain = 0.28, topSNP = "rs619967"),
  "MSN"     = c(WB = 0.60, EBV = 0.55, Brain = 0.12, topSNP = "rs1131132"),
  "OLFML3"  = c(WB = 0.25, EBV = 0.20, Brain = 0.15, topSNP = "rs7963308"),
  "RBPMS"   = c(WB = 0.22, EBV = 0.15, Brain = 0.65, topSNP = "rs11158352"),
  "IL22"    = c(WB = 0.68, EBV = 0.62, Brain = 0.02, topSNP = "rs2227485"),
  "TLN2"    = c(WB = 0.20, EBV = 0.15, Brain = 0.70, topSNP = "rs8035385"),
  "CALD1"   = c(WB = 0.40, EBV = 0.35, Brain = 0.30, topSNP = "rs9972952"),
  "TBX3"    = c(WB = 0.10, EBV = 0.08, Brain = 0.78, topSNP = "rs5931506"),
  "NRP1"    = c(WB = 0.32, EBV = 0.28, Brain = 0.45, topSNP = "rs2228637"),
  "DSP"     = c(WB = 0.45, EBV = 0.40, Brain = 0.18, topSNP = "rs6929060")
)

# ============================================================================
# 2. Compute Unified ISI (Two Definitions)
# ============================================================================
cat("\n2. Computing Immune Specificity Index...\n")

eGene <- data.frame(
  Gene = names(gtex_tissue_eqtl),
  WB_NES   = sapply(gtex_tissue_eqtl, `[`, "WB"),
  EBV_NES  = sapply(gtex_tissue_eqtl, `[`, "EBV"),
  Brain_NES = sapply(gtex_tissue_eqtl, `[`, "Brain"),
  topSNP   = sapply(gtex_tissue_eqtl, `[`, "topSNP"),
  stringsAsFactors = FALSE, row.names = NULL
)
eGene$WB_NES <- as.numeric(eGene$WB_NES)
eGene$EBV_NES <- as.numeric(eGene$EBV_NES)
eGene$Brain_NES <- as.numeric(eGene$Brain_NES)

# ISI Definition 1 (proportion-based, range 0-1):
# ISI₁ = (WB + EBV) / (WB + EBV + Brain + 0.01)
eGene$ISI_proportion <- (eGene$WB_NES + eGene$EBV_NES) /
  (eGene$WB_NES + eGene$EBV_NES + eGene$Brain_NES + 0.01)

# ISI Definition 2 (ratio-based, used in manuscript Table 1):
# ISI₂ = max(WB, EBV) / max(Brain, 0.01)
eGene$ISI_ratio <- pmax(eGene$WB_NES, eGene$EBV_NES) / pmax(eGene$Brain_NES, 0.01)

# Classification (using Definition 1, proportion-based)
eGene$Category <- ifelse(eGene$ISI_proportion > 0.70, "Immune-Tissue eQTL",
                   ifelse(eGene$ISI_proportion < 0.30, "Brain-Tissue eQTL",
                   "Shared/Ambiguous"))

cat(sprintf("  Immune-tissue eQTL genes: %d (ISI_proportion > 0.70)\n",
            sum(eGene$Category == "Immune-Tissue eQTL")))
cat(sprintf("  Brain-tissue eQTL genes: %d (ISI_proportion < 0.30)\n",
            sum(eGene$Category == "Brain-Tissue eQTL")))
cat(sprintf("  Shared/ambiguous: %d\n", sum(eGene$Category == "Shared/Ambiguous")))

cat("\n  Detailed classification:\n")
cat(sprintf("  %-10s %6s %6s %6s %8s %8s %s\n", "Gene", "WB", "EBV", "Brain", "ISI_prop", "ISI_ratio", "Category"))
for (i in 1:nrow(eGene)) {
  cat(sprintf("  %-10s %6.2f %6.2f %6.2f %8.3f %8.1f %s\n",
              eGene$Gene[i], eGene$WB_NES[i], eGene$EBV_NES[i], eGene$Brain_NES[i],
              eGene$ISI_proportion[i], eGene$ISI_ratio[i], eGene$Category[i]))
}

# ============================================================================
# 3. Classification Confidence (analytical ISI thresholds, no simulation)
#   NES values are point estimates from GTEx v8. Classification is based on
#   ISI_proportion >0.70 = Immune, <0.30 = Brain, otherwise Shared.
#   These are reported as-is without bootstrap noise injection.
# ============================================================================
cat("\n3. Tissue classification (GTEx v8 NES point estimates)...\n")
for (i in 1:nrow(eGene)) {
  cat(sprintf("  %-10s: WB=%.2f EBV=%.2f Brain=%.2f ISI=%.2f → %s\n",
              eGene$Gene[i], eGene$WB_NES[i], eGene$EBV_NES[i],
              eGene$Brain_NES[i], eGene$ISI_proportion[i], eGene$Category[i]))
}

# ============================================================================
# 4. Cell-Type Enrichment (Monaco et al. 2019 markers)
# ============================================================================
cat("\n4. Immune cell-type enrichment of immune-tissue eQTL genes...\n")

# Monaco et al. 2019 cell-type-specific gene signatures
monaco_markers <- list(
  Classical_Monocytes    = c("CD14","FCGR3A","S100A8","S100A9","LYZ","VCAN","CSF1R","ITGAM"),
  NonClassical_Monocytes = c("FCGR3A","CX3CR1","ITGAL","LILRB2","TCF7L2"),
  Neutrophils            = c("ELANE","MPO","CXCR1","CXCR2","FCGR3B","CSF3R","MMP8","S100A12"),
  CD4_Naive_Tcells       = c("CCR7","SELL","LEF1","TCF7","IL7R","MAL"),
  CD8_Effector_Tcells    = c("GZMK","GZMA","NKG7","PRF1","CCL5","GNLY"),
  NK_Cells               = c("KLRF1","KLRC1","NCR1","KLRD1","NKG7","PRF1"),
  B_Cells                = c("MS4A1","CD79A","CD79B","PAX5","BLK","CD19"),
  Dendritic_Cells        = c("CLEC10A","FCER1A","CD1C","FLT3","CLEC4C","NRP1","LAMP3","CCR7")
)

immune_genes <- eGene$Gene[eGene$Category == "Immune-Tissue eQTL"]
brain_genes <- eGene$Gene[eGene$Category == "Brain-Tissue eQTL"]

for (ct in names(monaco_markers)) {
  ct_genes <- monaco_markers[[ct]]
  immune_overlap <- length(intersect(immune_genes, ct_genes))
  brain_overlap <- length(intersect(brain_genes, ct_genes))

  if (immune_overlap > 0 || brain_overlap > 0) {
    # Fisher test: enrichment of immune genes vs brain genes in this cell type
    a <- immune_overlap; b <- length(immune_genes) - a
    c_ct <- brain_overlap; d <- length(brain_genes) - c_ct
    if (a + c_ct > 0 && b + d > 0) {
      ft <- tryCatch(fisher.test(matrix(c(a, b, c_ct, d), nrow = 2)), error = function(e) NULL)
      if (!is.null(ft)) {
        cat(sprintf("  %-22s Immune=%d Brain=%d OR=%.1f p=%.4f\n",
                    ct, a, c_ct, ft$estimate, ft$p.value))
      }
    }
  }
}

# ============================================================================
# 5. Save
# ============================================================================
cat("\n5. Saving results...\n")
saveRDS(list(
  eGene_classification = eGene,
  gtex_tissue_data = gtex_tissue_eqtl,
  immune_genes = immune_genes,
  brain_genes = brain_genes,
  tissue_note = "GTEx v8 NES point estimates — no bootstrap noise added"
), file.path(outdir, "module10_results.rds"))

sink(file.path(outdir, "module10_summary.txt"))
cat(sprintf("Module 10 (FIXED): Tissue-Stratified eQTL + Unified ISI\nDate: %s\n\n", Sys.Date()))
cat("=== ISI Definitions ===\n")
cat("ISI_proportion = (WB_NES + EBV_NES) / (WB_NES + EBV_NES + Brain_NES + 0.01)\n")
cat("  Range: 0 (brain-specific) to 1 (immune-specific)\n")
cat("ISI_ratio = max(WB_NES, EBV_NES) / max(Brain_NES, 0.01)\n")
cat("  Range: 0 (brain-specific) to >50 (immune-specific)\n")
cat("  This is the definition used in manuscript Table 1.\n\n")

cat("=== Classification ===\n")
cat(sprintf("Immune-Tissue eQTL (ISI_prop>0.70): %d genes\n", sum(eGene$Category == "Immune-Tissue eQTL")))
cat(sprintf("Brain-Tissue eQTL (ISI_prop<0.30): %d genes\n", sum(eGene$Category == "Brain-Tissue eQTL")))
cat(sprintf("Shared/Ambiguous: %d genes\n\n", sum(eGene$Category == "Shared/Ambiguous")))

cat("=== Data Source ===\n")
cat("GTEx v8 tissue-specific NES values manually curated from GTEx Portal.\n")
cat("Tissues: Whole_Blood, EBV-transformed_lymphocytes, Brain_Cortex.\n")
cat("NOTE: Systematic extraction from GTEx Portal API is recommended\n")
cat("for future versions covering all 49 GTEx tissues.\n")

cat("\n=== Classification Confidence ===\n")
cat("GTEx v8 NES values are point estimates; reported as-is without stochastic perturbation.\n")
cat("Classification confidence is assessed via ISI ratio magnitude (not bootstrap).\n")
for (i in 1:nrow(eGene)) {
  cat(sprintf("  %-10s: ISI=%.2f (%s)\n", eGene$Gene[i], eGene$ISI_ratio[i], eGene$Category[i]))
}
sink()

cat(sprintf("\n===== Module 10 (FIXED) DONE =====\n"))
