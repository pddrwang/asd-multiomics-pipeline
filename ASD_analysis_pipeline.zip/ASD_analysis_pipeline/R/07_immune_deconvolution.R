# ============================================================================
# Single-Dataset Immune Deconvolution for ASD-Immune Subtype
# ============================================================================
suppressMessages({library(GSVA); library(limma); library(ggplot2); library(reshape2); library(pheatmap)})

# Auto-detect project root
if (!requireNamespace("rstudioapi", quietly = TRUE)) install.packages("rstudioapi", repos = "https://cloud.r-project.org")
script_path <- tryCatch(rstudioapi::getActiveDocumentContext()$path, error = function(e) "")
if (script_path == "" || is.null(script_path)) {
  args <- commandArgs(trailingOnly = FALSE)
  fa <- grep("^--file=", args, value = TRUE)
  script_path <- if (length(fa) > 0) normalizePath(sub("^--file=", "", fa)) else normalizePath(".")
}
workdir <- normalizePath(dirname(script_path))
for (i in 1:5) {
  if (file.exists(file.path(workdir, "03_原始数据"))) break
  workdir <- dirname(workdir)
}
outdir  <- file.path(workdir, "分析结果")
figdir  <- file.path(outdir, "figures")
dir.create(figdir, showWarnings=FALSE, recursive=TRUE)

cat("===== Single-Dataset Immune Deconvolution =====\n\n")

# Load data
mod1 <- readRDS(file.path(outdir, "module1_results.rds"))
m4   <- readRDS(file.path(outdir, "module4_results.rds"))
expr <- mod1$expr; meta <- mod1$meta; st <- m4$subtypes

# Fix subtype labels
k2 <- st$K2
asd_blood <- meta$Diagnosis=="ASD" & meta$TissueSimple!="Brain"
asd_expr <- expr[, asd_blood]
fg <- m4$genes_used
imk <- intersect(c("IFITM3","CXCL16","HSPB1","ABCA1","JUN","IFITM2","MSN"), fg)
cd <- asd_expr[fg,]
oi <- mean(colMeans(cd[imk,,drop=FALSE], na.rm=TRUE))
cn <- c()
for(cl in sort(unique(k2))) {
  vs <- intersect(st$Sample[k2==cl], colnames(cd))
  imm <- mean(colMeans(cd[imk, vs, drop=FALSE], na.rm=TRUE))
  cn[as.character(cl)] <- ifelse(imm > oi, "ASD-Immune", "ASD-Synaptic")
}
st$Subtype <- cn[as.character(k2)]
cat(sprintf("Subtypes fixed: Immune=%d, Synaptic=%d\n\n",
            sum(st$Subtype=="ASD-Immune"), sum(st$Subtype=="ASD-Synaptic")))

# LM22 signatures
lm22 <- list(
  B_cells_naive=c("CD19","CD79A","CD79B","MS4A1","BLK","FCRL2","PAX5"),
  B_cells_memory=c("CD27","CD38","TNFRSF17","SDC1","SLAMF7","IRF4"),
  T_cells_CD8=c("CD8A","CD8B","GZMK","GZMA","PRF1","NKG7","GNLY","CCL5"),
  T_cells_CD4_naive=c("CCR7","SELL","LEF1","TCF7","IL7R","CD27","CD28"),
  T_cells_follicular_helper=c("BCL6","CXCR5","PDCD1","ICOS","IL21","CD200"),
  T_cells_regulatory_Tregs=c("FOXP3","IL2RA","CTLA4","TNFRSF18","IKZF2","TIGIT"),
  NK_cells_resting=c("KIR2DL1","KIR2DL3","KIR3DL1","IL2RB","KLRF1"),
  NK_cells_activated=c("GZMB","PRF1","IFNG","CCL3","CCL4","KLRK1"),
  Monocytes=c("CD14","FCGR3A","CSF1R","ITGAM","CD33","CD68","S100A8","S100A9","LYZ"),
  Macrophages_M1=c("IL1B","TNF","IL6","IL12A","CXCL9","CXCL10","CCL5"),
  Macrophages_M2=c("CD163","MRC1","MSR1","IL10","TGFB1","CCL18","CCL22"),
  Dendritic_cells_resting=c("FCER1A","CLEC10A","CD1C","FLT3","CLEC4C"),
  Dendritic_cells_activated=c("CD83","CCR7","LAMP3","CD40","CD80","CD86"),
  Neutrophils=c("FCGR3B","CXCR1","CXCR2","CSF3R","ELANE","MPO","BPI","LTF","MMP8"),
  Eosinophils=c("CCR3","IL5RA","SIGLEC8","RNASE2","RNASE3"),
  Mast_cells=c("KIT","TPSAB1","CPA3","HDC","MS4A2","GATA2")
)

all_results <- list()
all_ct_stats <- list()

# ---- DATASET 1: GSE18123 (Childhood Blood, GPL570) ----
cat("=== GSE18123 (Childhood Blood) ===\n")

# Load raw GSE18123 data and map probes to genes
library(GEOquery)
gse18123 <- getGEO(filename=file.path(workdir,"原始数据/GEO/GSE18123/GSE18123_series_matrix.txt.gz"),
                   AnnotGPL=FALSE, getGPL=FALSE)
expr18123_raw <- exprs(gse18123)
gpl570 <- getGEO(filename=file.path(workdir,"原始数据/GEO/GSE18123/GPL570.annot.gz"))
g18123 <- trimws(gsub("///.*","",as.character(Table(gpl570)[["Gene symbol"]])[match(rownames(expr18123_raw),Table(gpl570)$ID)]))
keep <- !is.na(g18123)&g18123!=""
expr18123_raw <- expr18123_raw[keep,]; g18123 <- g18123[keep]
# Collapse to gene-level
gl <- split(seq_len(nrow(expr18123_raw)), g18123)
expr18123 <- t(sapply(gl, function(idx) {
  if(length(idx)==1) expr18123_raw[idx,] else { iqrs <- apply(expr18123_raw[idx,,drop=FALSE],1,IQR,na.rm=TRUE); expr18123_raw[idx[which.max(iqrs)],] }
}))
cat(sprintf("  GSE18123 gene-level: %d genes x %d samples\n", nrow(expr18123), ncol(expr18123)))

# Parse diagnosis
src18123 <- as.character(pData(gse18123)$source_name_ch1)
diag18123 <- ifelse(grepl("autism|Autism", src18123), "ASD", "Control")
names(diag18123) <- colnames(expr18123)

# Get ASD samples with subtype labels
st18123 <- st[st$Dataset=="GSE18123",]
asd_samples <- intersect(gsub("GSE18123_", "", st18123$Sample), colnames(expr18123))
ctrl_samples <- colnames(expr18123)[diag18123=="Control"]
cat(sprintf("  ASD: %d matched, Control: %d\n", length(asd_samples), length(ctrl_samples)))

e18123 <- cbind(expr18123[, asd_samples, drop=FALSE], expr18123[, ctrl_samples, drop=FALSE])
groups18123 <- c(st18123$Subtype[match(asd_samples, gsub("GSE18123_","",st18123$Sample))], rep("Control", length(ctrl_samples)))

# Filter LM22 to genes in full dataset
lm22_18123 <- lapply(lm22, function(gs) intersect(gs, rownames(e18123)))
lm22_18123 <- lm22_18123[sapply(lm22_18123, length) >= 3]
n_types_18123 <- length(lm22_18123)
cat(sprintf("  LM22 evaluable: %d/16\n", n_types_18123))

# ssGSEA
set.seed(42)
ssgsea18123 <- gsva(ssgseaParam(as.matrix(e18123), lm22_18123, normalize=TRUE), verbose=FALSE)
if(!is.matrix(ssgsea18123)) ssgsea18123 <- assay(ssgsea18123)

# Stats
ct18123 <- data.frame(stringsAsFactors=FALSE)
for(ct in rownames(ssgsea18123)) {
  si <- ssgsea18123[ct, groups18123=="ASD-Immune"]; ss <- ssgsea18123[ct, groups18123=="ASD-Synaptic"]; sc <- ssgsea18123[ct, groups18123=="Control"]
  p_is <- tryCatch(wilcox.test(si, ss)$p.value, error=function(e)1)
  p_ic <- tryCatch(wilcox.test(si, sc)$p.value, error=function(e)1)
  ct18123 <- rbind(ct18123, data.frame(CellType=ct, Mean_Immune=mean(si), Mean_Synaptic=mean(ss), Mean_Control=mean(sc), P_IS=p_is, P_IC=p_ic, stringsAsFactors=FALSE))
}
ct18123$FDR_IS <- p.adjust(ct18123$P_IS, method="BH"); ct18123$FDR_IC <- p.adjust(ct18123$P_IC, method="BH")
ct18123 <- ct18123[order(ct18123$P_IC),]

cat(sprintf("  Significant Immune_vs_Control (FDR<0.05): %d\n", sum(ct18123$FDR_IC<0.05)))
for(j in 1:min(8, nrow(ct18123))) {
  cat(sprintf("    %-25s I=%.3f S=%.3f C=%.3f P_IC=%.4f FDR_IC=%.4f\n",
              ct18123$CellType[j], ct18123$Mean_Immune[j], ct18123$Mean_Synaptic[j], ct18123$Mean_Control[j], ct18123$P_IC[j], ct18123$FDR_IC[j]))
}

all_results[["GSE18123"]] <- list(ssgsea=ssgsea18123, groups=groups18123, n_types=n_types_18123)
all_ct_stats[["GSE18123"]] <- ct18123

# ---- DATASET 2: GSE123302 (Cord Blood, GPL16686) ----
cat("\n=== GSE123302 (Cord Blood) ===\n")

gse123302 <- getGEO(filename=file.path(workdir,"原始数据/GEO/GSE123302/GSE123302_series_matrix.txt.gz"),
                    AnnotGPL=FALSE, getGPL=FALSE)
expr12302_raw <- exprs(gse123302)
gpl16686 <- getGEO(filename=file.path(workdir,"原始数据/GEO/GSE123302/GPL16686.soft.gz"))
# Map via RefSeq
library(org.Hs.eg.db); library(AnnotationDbi)
acc12302 <- as.character(Table(gpl16686)$GB_ACC)[match(rownames(expr12302_raw), Table(gpl16686)$ID)]
valid <- acc12302!="" & !is.na(acc12302)
sym12302 <- rep(NA, length(acc12302))
if(any(valid)) {
  mapped <- suppressMessages(AnnotationDbi::select(org.Hs.eg.db, keys=acc12302[valid], columns="SYMBOL", keytype="REFSEQ"))
  mapped <- mapped[!duplicated(mapped$REFSEQ),]
  mm <- match(acc12302, mapped$REFSEQ); sym12302 <- mapped$SYMBOL[mm]
}
keep <- !is.na(sym12302)&sym12302!=""
expr12302_raw <- expr12302_raw[keep,]; sym12302 <- sym12302[keep]
gl <- split(seq_len(nrow(expr12302_raw)), sym12302)
expr12302 <- t(sapply(gl, function(idx) {
  if(length(idx)==1) expr12302_raw[idx,] else { iqrs <- apply(expr12302_raw[idx,,drop=FALSE],1,IQR,na.rm=TRUE); expr12302_raw[idx[which.max(iqrs)],] }
}))
cat(sprintf("  GSE123302 gene-level: %d genes x %d samples\n", nrow(expr12302), ncol(expr12302)))

char12302 <- as.character(pData(gse123302)$characteristics_ch1)
diag12302 <- ifelse(grepl("ASD|autism", char12302), "ASD", "Control")

st12302 <- st[st$Dataset=="GSE123302",]
asd_samples <- intersect(gsub("GSE123302_", "", st12302$Sample), colnames(expr12302))
ctrl_samples <- colnames(expr12302)[diag12302=="Control"]
cat(sprintf("  ASD: %d matched, Control: %d\n", length(asd_samples), length(ctrl_samples)))

e12302 <- cbind(expr12302[, asd_samples, drop=FALSE], expr12302[, ctrl_samples, drop=FALSE])
groups12302 <- c(st12302$Subtype[match(asd_samples, gsub("GSE123302_","",st12302$Sample))], rep("Control", length(ctrl_samples)))

lm22_12302 <- lapply(lm22, function(gs) intersect(gs, rownames(e12302)))
lm22_12302 <- lm22_12302[sapply(lm22_12302, length) >= 3]
n_types_12302 <- length(lm22_12302)
cat(sprintf("  LM22 evaluable: %d/16\n", n_types_12302))

set.seed(42)
ssgsea12302 <- gsva(ssgseaParam(as.matrix(e12302), lm22_12302, normalize=TRUE), verbose=FALSE)
if(!is.matrix(ssgsea12302)) ssgsea12302 <- assay(ssgsea12302)

ct12302 <- data.frame(stringsAsFactors=FALSE)
for(ct in rownames(ssgsea12302)) {
  si <- ssgsea12302[ct, groups12302=="ASD-Immune"]; ss <- ssgsea12302[ct, groups12302=="ASD-Synaptic"]; sc <- ssgsea12302[ct, groups12302=="Control"]
  p_is <- tryCatch(wilcox.test(si, ss)$p.value, error=function(e)1)
  p_ic <- tryCatch(wilcox.test(si, sc)$p.value, error=function(e)1)
  ct12302 <- rbind(ct12302, data.frame(CellType=ct, Mean_Immune=mean(si), Mean_Synaptic=mean(ss), Mean_Control=mean(sc), P_IS=p_is, P_IC=p_ic, stringsAsFactors=FALSE))
}
ct12302$FDR_IS <- p.adjust(ct12302$P_IS, method="BH"); ct12302$FDR_IC <- p.adjust(ct12302$P_IC, method="BH")
ct12302 <- ct12302[order(ct12302$P_IC),]

cat(sprintf("  Significant Immune_vs_Control (FDR<0.05): %d\n", sum(ct12302$FDR_IC<0.05)))
for(j in 1:min(8, nrow(ct12302))) {
  cat(sprintf("    %-25s I=%.3f S=%.3f C=%.3f P_IC=%.4f FDR_IC=%.4f\n",
              ct12302$CellType[j], ct12302$Mean_Immune[j], ct12302$Mean_Synaptic[j], ct12302$Mean_Control[j], ct12302$P_IC[j], ct12302$FDR_IC[j]))
}

all_results[["GSE123302"]] <- list(ssgsea=ssgsea12302, groups=groups12302, n_types=n_types_12302)
all_ct_stats[["GSE123302"]] <- ct12302

# ---- DATASET 3: GSE148450 (Maternal Blood, GPL25483) ----
cat("\n=== GSE148450 (Maternal Blood) ===\n")

gse148450 <- getGEO(filename=file.path(workdir,"原始数据/GEO/GSE148450/GSE148450_series_matrix.txt.gz"),
                    AnnotGPL=FALSE, getGPL=FALSE)
expr148450_raw <- exprs(gse148450)
# GPL25483 has gene symbols as row names
g148450 <- rownames(expr148450_raw)
keep <- !is.na(g148450)&g148450!=""&!grepl("^\\d",g148450)
expr148450_raw <- expr148450_raw[keep,]; g148450 <- g148450[keep]
gl <- split(seq_len(nrow(expr148450_raw)), g148450)
expr148450 <- t(sapply(gl, function(idx) {
  if(length(idx)==1) expr148450_raw[idx,] else { iqrs <- apply(expr148450_raw[idx,,drop=FALSE],1,IQR,na.rm=TRUE); expr148450_raw[idx[which.max(iqrs)],] }
}))
cat(sprintf("  GSE148450 gene-level: %d genes x %d samples\n", nrow(expr148450), ncol(expr148450)))

char148450 <- as.character(pData(gse148450)$characteristics_ch1)
diag148450 <- ifelse(grepl("ASD|autism", char148450), "ASD", "Control")

st148450 <- st[st$Dataset=="GSE148450",]
asd_samples <- intersect(gsub("GSE148450_", "", st148450$Sample), colnames(expr148450))
ctrl_samples <- colnames(expr148450)[diag148450=="Control"]
cat(sprintf("  ASD: %d matched, Control: %d\n", length(asd_samples), length(ctrl_samples)))

e148450 <- cbind(expr148450[, asd_samples, drop=FALSE], expr148450[, ctrl_samples, drop=FALSE])
groups148450 <- c(st148450$Subtype[match(asd_samples, gsub("GSE148450_","",st148450$Sample))], rep("Control", length(ctrl_samples)))

lm22_148450 <- lapply(lm22, function(gs) intersect(gs, rownames(e148450)))
lm22_148450 <- lm22_148450[sapply(lm22_148450, length) >= 3]
n_types_148450 <- length(lm22_148450)
cat(sprintf("  LM22 evaluable: %d/16\n", n_types_148450))

set.seed(42)
ssgsea148450 <- gsva(ssgseaParam(as.matrix(e148450), lm22_148450, normalize=TRUE), verbose=FALSE)
if(!is.matrix(ssgsea148450)) ssgsea148450 <- assay(ssgsea148450)

ct148450 <- data.frame(stringsAsFactors=FALSE)
for(ct in rownames(ssgsea148450)) {
  si <- ssgsea148450[ct, groups148450=="ASD-Immune"]; ss <- ssgsea148450[ct, groups148450=="ASD-Synaptic"]; sc <- ssgsea148450[ct, groups148450=="Control"]
  p_is <- tryCatch(wilcox.test(si, ss)$p.value, error=function(e)1)
  p_ic <- tryCatch(wilcox.test(si, sc)$p.value, error=function(e)1)
  ct148450 <- rbind(ct148450, data.frame(CellType=ct, Mean_Immune=mean(si), Mean_Synaptic=mean(ss), Mean_Control=mean(sc), P_IS=p_is, P_IC=p_ic, stringsAsFactors=FALSE))
}
ct148450$FDR_IS <- p.adjust(ct148450$P_IS, method="BH"); ct148450$FDR_IC <- p.adjust(ct148450$P_IC, method="BH")
ct148450 <- ct148450[order(ct148450$P_IC),]

cat(sprintf("  Significant Immune_vs_Control (FDR<0.05): %d\n", sum(ct148450$FDR_IC<0.05)))
for(j in 1:min(8, nrow(ct148450))) {
  cat(sprintf("    %-25s I=%.3f S=%.3f C=%.3f P_IC=%.4f FDR_IC=%.4f\n",
              ct148450$CellType[j], ct148450$Mean_Immune[j], ct148450$Mean_Synaptic[j], ct148450$Mean_Control[j], ct148450$P_IC[j], ct148450$FDR_IC[j]))
}

all_results[["GSE148450"]] <- list(ssgsea=ssgsea148450, groups=groups148450, n_types=n_types_148450)
all_ct_stats[["GSE148450"]] <- ct148450

# ---- SAVE ----
saveRDS(list(results=all_results, ct_stats=all_ct_stats, subtype_labels=st),
        file.path(outdir, "single_dataset_immune_results.rds"))

# ---- CROSS-DATASET SUMMARY ----
cat("\n\n========== CROSS-DATASET SUMMARY ==========\n\n")
for(ds in c("GSE18123","GSE123302","GSE148450")) {
  r <- all_results[[ds]]
  cts <- all_ct_stats[[ds]]
  cat(sprintf("=== %s: %d LM22 types, %d samples ===\n", ds, r$n_types, length(r$groups)))
  
  # Immune vs Control: significant
  sig_ic <- cts[cts$FDR_IC < 0.05,]
  if(nrow(sig_ic) > 0) {
    cat("  Immune > Control (FDR<0.05):\n")
    for(j in 1:nrow(sig_ic)) cat(sprintf("    %s: +%.3f\n", sig_ic$CellType[j], sig_ic$Mean_Immune[j]-sig_ic$Mean_Control[j]))
  }
  
  # Immune vs Synaptic
  sig_is <- cts[cts$FDR_IS < 0.05,]
  if(nrow(sig_is) > 0) {
    cat("  Immune > Synaptic (FDR<0.05):\n")
    for(j in 1:nrow(sig_is)) cat(sprintf("    %s: +%.3f\n", sig_is$CellType[j], sig_is$Mean_Immune[j]-sig_is$Mean_Synaptic[j]))
  }
  cat("\n")
}

# Top immune-elevated cell types across all datasets
cat("=== Consensus immune-elevated cell types ===\n")
cell_type_ranks <- list()
for(ds in c("GSE18123","GSE123302","GSE148450")) {
  cts <- all_ct_stats[[ds]]
  cell_type_ranks[[ds]] <- cts$CellType[order(cts$Mean_Immune - cts$Mean_Control, decreasing=TRUE)][1:5]
}
cat("GSE18123: "); cat(paste(cell_type_ranks[["GSE18123"]], collapse=", ")); cat("\n")
cat("GSE123302: "); cat(paste(cell_type_ranks[["GSE123302"]], collapse=", ")); cat("\n")
cat("GSE148450: "); cat(paste(cell_type_ranks[["GSE148450"]], collapse=", ")); cat("\n")

# Cross-dataset consensus
all_top5 <- unlist(cell_type_ranks)
consensus_immune <- names(sort(table(all_top5), decreasing=TRUE))[1:5]
cat(sprintf("\nCross-dataset consensus (top 5): %s\n", paste(consensus_immune, collapse=", ")))

cat("\n===== Single-dataset immune analysis COMPLETE =====\n")
