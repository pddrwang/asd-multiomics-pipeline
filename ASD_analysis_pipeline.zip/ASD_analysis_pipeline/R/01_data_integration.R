# ============================================================================
# Module 1 (FIXED): Multi-Tissue Data Integration — All 5 GEO Datasets
# Fixes:
#   1. Includes GSE28521 (79 brain samples) — previously missing from unified matrix
#   2. Correct sample count: 402 blood + 115 brain = 517 total
#   3. PCA variance partitioning: batch vs diagnosis vs tissue
#   4. Positive control (housekeeping genes) analysis
#   5. Detailed sample table output
# ============================================================================
suppressMessages({
  library(limma)
  library(sva)
  library(org.Hs.eg.db)
  library(GEOquery)
  library(ggplot2)
})

# Auto-detect project root
if (!requireNamespace("rstudioapi", quietly = TRUE)) install.packages("rstudioapi", repos = "https://cloud.r-project.org")
script_path <- tryCatch(rstudioapi::getActiveDocumentContext()$path, error = function(e) "")
if (script_path == "" || is.null(script_path)) {
  args <- commandArgs(trailingOnly = FALSE)
  fa <- grep("^--file=", args, value = TRUE)
  script_path <- if (length(fa) > 0) normalizePath(sub("^--file=", "", fa)) else normalizePath(".")
}
workdir <- normalizePath(dirname(script_path))
for (i in 1:5) {
  if (file.exists(file.path(workdir, "03_原始数据"))) break
  workdir <- dirname(workdir)
}
datadir <- file.path(workdir, "原始数据/GEO")
outdir  <- file.path(workdir, "分析结果")
dir.create(outdir, showWarnings = FALSE, recursive = TRUE)

cat("===== Module 1 (FIXED): 5-Dataset Integration =====\n\n")

# ============================================================================
# Helper: probe-to-gene collapse (max-IQR probe per gene)
# ============================================================================
collapse_to_genes <- function(expr, gene_symbols) {
  gene_list <- split(seq_len(nrow(expr)), gene_symbols)
  t(sapply(gene_list, function(idx) {
    if (length(idx) == 1) return(expr[idx, ])
    iqrs <- apply(expr[idx, , drop = FALSE], 1, IQR, na.rm = TRUE)
    expr[idx[which.max(iqrs)], ]
  }))
}

# ============================================================================
# 1. GSE18123 — Childhood Blood, GPL570 (Affymetrix U133 Plus 2.0)
# ============================================================================
cat("1/5 GSE18123 (Childhood Blood, GPL570)...\n")
e1 <- as.matrix(read.csv(file.path(datadir, "GSE18123/GSE18123_expression_matrix_log2.csv"),
                          row.names = 1, check.names = FALSE))
gpl570 <- getGEO(filename = file.path(datadir, "GSE18123/GPL570.annot.gz"))
tab1 <- Table(gpl570)
m1 <- match(rownames(e1), tab1$ID)
g1 <- trimws(gsub("///.*", "", as.character(tab1[["Gene symbol"]])[m1]))
keep <- !is.na(g1) & g1 != ""
e1 <- e1[keep, ]; g1 <- g1[keep]
e1g <- collapse_to_genes(e1, g1)

pheno1 <- read.csv(file.path(datadir, "GSE18123/GSE18123_group_info.csv"), stringsAsFactors = FALSE)
rownames(pheno1) <- pheno1$Sample
pheno1 <- pheno1[colnames(e1), ]
diag1 <- trimws(gsub("^diagnosis:\\s*", "", pheno1$Diagnosis, ignore.case = FALSE))
grp1 <- ifelse(diag1 == "CONTROL", "Control",
        ifelse(diag1 %in% c("AUTISM", "ASPERGER'S DISORDER", "PDD-NOS"), "ASD", "Other"))
keep_s <- grp1 %in% c("ASD", "Control")
e1g <- e1g[, keep_s]; grp1 <- grp1[keep_s]
colnames(e1g) <- paste0("GSE18123_", colnames(e1g))
cat(sprintf("  %d genes x %d samples (%d ASD, %d Control)\n", nrow(e1g), ncol(e1g), sum(grp1=="ASD"), sum(grp1=="Control")))

# ============================================================================
# 2. GSE123302 — Cord Blood, GPL16686 (Affymetrix Gene 2.1 ST)
# ============================================================================
cat("2/5 GSE123302 (Cord Blood, GPL16686)...\n")
e2 <- as.matrix(read.csv(file.path(datadir, "GSE123302/GSE123302_expression_matrix.csv"),
                          row.names = 1, check.names = FALSE))
gpl16686 <- getGEO(filename = file.path(datadir, "GSE123302/GPL16686.soft.gz"))
tab2 <- Table(gpl16686)
m2 <- match(rownames(e2), tab2$ID)
acc2 <- as.character(tab2$GB_ACC)[m2]

valid2 <- acc2 != "" & !is.na(acc2)
sym2 <- rep(NA, length(acc2))
if (any(valid2)) {
  mapped <- suppressMessages(select(org.Hs.eg.db, keys = acc2[valid2],
                                    columns = "SYMBOL", keytype = "REFSEQ"))
  mapped <- mapped[!duplicated(mapped$REFSEQ), ]
  mm <- match(acc2, mapped$REFSEQ)
  sym2 <- mapped$SYMBOL[mm]
}
keep <- !is.na(sym2) & sym2 != ""
e2 <- e2[keep, ]; sym2 <- sym2[keep]
e2g <- collapse_to_genes(e2, sym2)

pheno2 <- read.csv(file.path(datadir, "GSE123302/GSE123302_group_info.csv"), stringsAsFactors = FALSE)
grp2 <- pheno2$Group; grp2[grp2 == "TD"] <- "Control"
colnames(e2g) <- paste0("GSE123302_", colnames(e2g))
cat(sprintf("  %d genes x %d samples (%d ASD, %d Control)\n", nrow(e2g), ncol(e2g), sum(grp2=="ASD"), sum(grp2=="Control")))

# ============================================================================
# 3. GSE148450 — Maternal Blood, GPL25483 (Phalanx OneArray)
# ============================================================================
cat("3/5 GSE148450 (Maternal Blood, GPL25483)...\n")
e3 <- as.matrix(read.csv(file.path(datadir, "GSE148450/GSE148450_expression_matrix.csv"),
                          row.names = 1, check.names = FALSE))
g3 <- rownames(e3)
keep <- !is.na(g3) & g3 != "" & !grepl("^\\d", g3)
e3 <- e3[keep, ]; g3 <- g3[keep]
e3g <- collapse_to_genes(e3, g3)

pheno3 <- read.csv(file.path(datadir, "GSE148450/GSE148450_group_info.csv"), stringsAsFactors = FALSE)
grp3 <- pheno3$Group; grp3[grp3 == "TD"] <- "Control"
colnames(e3g) <- paste0("GSE148450_", colnames(e3g))
cat(sprintf("  %d genes x %d samples (%d ASD, %d Control)\n", nrow(e3g), ncol(e3g), sum(grp3=="ASD"), sum(grp3=="Control")))

# ============================================================================
# 4. GSE38322 — Brain Postmortem, GPL10558 (Illumina HT-12 v4.0)
# ============================================================================
cat("4/5 GSE38322 (Brain, GPL10558)...\n")
e4 <- as.matrix(read.csv(file.path(datadir, "GSE38322/GSE38322_expression_matrix.csv"),
                          row.names = 1, check.names = FALSE))
gpl10558 <- getGEO(filename = file.path(datadir, "GSE38322/GPL10558.annot.gz"))
tab4 <- Table(gpl10558)
m4 <- match(rownames(e4), tab4$ID)
g4 <- trimws(as.character(tab4[["Gene symbol"]])[m4])
keep <- !is.na(g4) & g4 != ""
e4 <- e4[keep, ]; g4 <- g4[keep]
e4g <- collapse_to_genes(e4, g4)

diag4_rds <- readRDS(file.path(datadir, "GSE38322/GSE38322_diagnosis.rds"))
diag4 <- diag4_rds[colnames(e4)]
colnames(e4g) <- paste0("GSE38322_", colnames(e4g))
cat(sprintf("  %d genes x %d samples (%d ASD, %d Control)\n", nrow(e4g), ncol(e4g), sum(diag4=="ASD"), sum(diag4=="Control")))

# ============================================================================
# 5. GSE28521 — Brain Postmortem, GPL6883 (Illumina HumanRef-8 v3.0) [NEW!]
# ============================================================================
cat("5/5 GSE28521 (Brain, GPL6883) — NEWLY INTEGRATED...\n")

# Parse GSE28521 from series matrix
gse28521 <- getGEO(filename = file.path(datadir, "GSE28521/GSE28521_series_matrix.txt.gz"),
                   AnnotGPL = FALSE, getGPL = FALSE)
e5 <- exprs(gse28521)

# Parse diagnosis from characteristics
char5 <- as.character(pData(gse28521)$characteristics_ch1)
# "disease status: autism" or "disease status: controls"
diag5 <- ifelse(grepl("autism", char5), "ASD",
         ifelse(grepl("controls", char5), "Control", "Other"))
names(diag5) <- colnames(e5)

# Parse brain region
char5_region <- as.character(pData(gse28521)$characteristics_ch1.1)
region5 <- gsub("^tissue \\(brain region\\):\\s*", "", char5_region)

# Map probes to gene symbols via GPL6883
gpl6883 <- getGEO(filename = file.path(datadir, "GSE28521/GPL6883.annot.gz"))
tab5 <- Table(gpl6883)
m5 <- match(rownames(e5), tab5$ID)
g5 <- trimws(as.character(tab5[["Gene symbol"]])[m5])
keep <- !is.na(g5) & g5 != ""
e5 <- e5[keep, ]; g5 <- g5[keep]
# Data already log2-normalized
e5g <- collapse_to_genes(e5, g5)

diag5 <- diag5[colnames(e5)]
region5 <- region5[colnames(e5)]
colnames(e5g) <- paste0("GSE28521_", colnames(e5g))
cat(sprintf("  %d genes x %d samples (%d ASD, %d Control, 3 brain regions)\n",
            nrow(e5g), ncol(e5g), sum(diag5=="ASD"), sum(diag5=="Control")))
cat(sprintf("  Regions: %s\n", paste(names(table(region5)), collapse=", ")))

# ============================================================================
# 6. Gene Intersection
# ============================================================================
cat("\n===== Step 6: Gene Intersection =====\n")
common <- Reduce(intersect, list(rownames(e1g), rownames(e2g), rownames(e3g),
                                  rownames(e4g), rownames(e5g)))
cat(sprintf("Common genes across all 5 datasets: %d\n", length(common)))

m1f <- e1g[common, ]; m2f <- e2g[common, ]; m3f <- e3g[common, ]
m4f <- e4g[common, ]; m5f <- e5g[common, ]

unified <- cbind(m1f, m2f, m3f, m4f, m5f)
cat(sprintf("Unified matrix: %d genes x %d samples\n", nrow(unified), ncol(unified)))

# ============================================================================
# 7. Low-Expression Filter
# ============================================================================
cat("\n===== Step 7: Low-Expression Filter =====\n")
gene_rate <- rowMeans(unified > 2)
keep_genes <- gene_rate >= 0.10
unified <- unified[keep_genes, ]
cat(sprintf("After filter: %d genes (removed %d low-expr)\n", nrow(unified), sum(!keep_genes)))

# ============================================================================
# 8. Quantile Normalization Within Each Dataset
# ============================================================================
cat("\n===== Step 8: Quantile Normalization =====\n")
batch <- rep(c("GSE18123","GSE123302","GSE148450","GSE38322","GSE28521"),
             c(ncol(m1f), ncol(m2f), ncol(m3f), ncol(m4f), ncol(m5f)))
for (b in unique(batch)) {
  idx <- which(batch == b)
  unified[, idx] <- normalizeBetweenArrays(unified[, idx], method = "quantile")
}
cat("Quantile normalization completed within each dataset.\n")

# ============================================================================
# 9. Build Metadata
# ============================================================================
cat("\n===== Step 9: Metadata =====\n")
diagnosis <- c(grp1, grp2, grp3, diag4, diag5)
names(diagnosis) <- colnames(unified)

tissue <- c(rep("Peripheral_Blood", ncol(m1f)),
            rep("Cord_Blood", ncol(m2f)),
            rep("Maternal_Blood", ncol(m3f)),
            rep("Brain_GSE38322", ncol(m4f)),
            rep("Brain_GSE28521", ncol(m5f)))

platform <- c(rep("GPL570_Affy_U133Plus2", ncol(m1f)),
              rep("GPL16686_Affy_Gene2.1ST", ncol(m2f)),
              rep("GPL25483_Phalanx_OneArray", ncol(m3f)),
              rep("GPL10558_Illumina_HT12v4", ncol(m4f)),
              rep("GPL6883_Illumina_HumanRef8v3", ncol(m5f)))

tissue_simple <- ifelse(grepl("Brain", tissue), "Brain",
                 ifelse(tissue == "Cord_Blood", "Cord_Blood",
                 ifelse(tissue == "Maternal_Blood", "Maternal_Blood", "Peripheral_Blood")))

stage <- c(rep("Childhood", ncol(m1f)),
           rep("Birth", ncol(m2f)),
           rep("Prenatal", ncol(m3f)),
           rep("Postmortem", ncol(m4f)),
           rep("Postmortem", ncol(m5f)))

meta <- data.frame(
  Sample      = colnames(unified),
  Dataset     = batch,
  Tissue      = tissue,
  TissueSimple = tissue_simple,
  Platform    = platform,
  Stage       = stage,
  Diagnosis   = diagnosis,
  stringsAsFactors = FALSE
)
rownames(meta) <- meta$Sample

cat("\nSample breakdown (TissueSimple x Diagnosis):\n")
print(table(meta$TissueSimple, meta$Diagnosis))
cat(sprintf("\nTotal samples: %d (Blood: %d, Brain: %d)\n",
            nrow(meta), sum(meta$TissueSimple != "Brain"), sum(meta$TissueSimple == "Brain")))

# ============================================================================
# 10. ComBat Batch Correction
# ============================================================================
cat("\n===== Step 10: ComBat Batch Correction =====\n")
# Handle NAs: first filter genes with >20% missing, then impute remainder
na_count <- sum(is.na(unified))
cat(sprintf("NAs in unified matrix: %d (%.1f%%)\n", na_count, na_count/prod(dim(unified))*100))
gene_na_rate <- rowMeans(is.na(unified))
keep_na <- gene_na_rate <= 0.20
cat(sprintf("Genes with <=20%% NAs: %d/%d (removing %d)\n", 
            sum(keep_na), length(keep_na), sum(!keep_na)))
unified <- unified[keep_na, ]
# Impute remaining NAs with row median
na_remain <- sum(is.na(unified))
if (na_remain > 0) {
  for (i in seq_len(nrow(unified))) {
    na_idx <- which(is.na(unified[i, ]))
    if (length(na_idx) > 0 && length(na_idx) < ncol(unified)) {
      row_med <- median(unified[i, ], na.rm = TRUE)
      if (!is.na(row_med)) unified[i, na_idx] <- row_med
    }
  }
  cat(sprintf("After imputation: %d NAs remain\n", sum(is.na(unified))))
}
mod_combat <- model.matrix(~ Diagnosis, data = meta)
unified_corrected <- ComBat(dat = unified, batch = batch, mod = mod_combat,
                             par.prior = TRUE, prior.plots = FALSE)
cat("ComBat completed.\n")

# ============================================================================
# 11. PCA Diagnostics
# ============================================================================
cat("\n===== Step 11: PCA Diagnostics =====\n")
pca_res <- prcomp(t(unified_corrected), center = TRUE, scale. = TRUE, rank. = 50)
pca_scores <- as.data.frame(pca_res$x)
pca_var <- summary(pca_res)$importance[2, ] * 100

# Variance explained by batch, diagnosis, tissue in top 20 PCs
batch_r2 <- sapply(1:20, function(i) summary(lm(pca_scores[, i] ~ meta$Dataset))$r.squared)
diag_r2  <- sapply(1:20, function(i) summary(lm(pca_scores[, i] ~ meta$Diagnosis))$r.squared)
tissue_r2 <- sapply(1:20, function(i) summary(lm(pca_scores[, i] ~ meta$TissueSimple))$r.squared)

cat(sprintf("PC1 (%.1f%% var): Batch R²=%.3f, Diagnosis R²=%.3f, Tissue R²=%.3f\n",
            pca_var[1], batch_r2[1], diag_r2[1], tissue_r2[1]))
cat(sprintf("PC2 (%.1f%% var): Batch R²=%.3f, Diagnosis R²=%.3f, Tissue R²=%.3f\n",
            pca_var[2], batch_r2[2], diag_r2[2], tissue_r2[2]))
cat(sprintf("PC3 (%.1f%% var): Batch R²=%.3f, Diagnosis R²=%.3f, Tissue R²=%.3f\n",
            pca_var[3], batch_r2[3], diag_r2[3], tissue_r2[3]))
cat(sprintf("Cumulative top-10 PCs: Batch R²=%.3f, Diagnosis R²=%.3f, Tissue R²=%.3f\n",
            sum(batch_r2[1:10]), sum(diag_r2[1:10]), sum(tissue_r2[1:10])))

# ============================================================================
# 12. Housekeeping Gene Controls
# ============================================================================
cat("\n===== Step 12: Housekeeping Gene Controls =====\n")
hk_genes <- intersect(c("GAPDH","ACTB","B2M","RPLP0","PPIA","HPRT1","TBP",
                         "RPL13A","SDHA","YWHAZ","UBC","HMBS","GUSB"), rownames(unified_corrected))
if (length(hk_genes) >= 5) {
  hk_expr <- unified_corrected[hk_genes, ]
  hk_cv <- sapply(hk_genes, function(g) {
    tissue_means <- sapply(unique(meta$TissueSimple), function(t) mean(hk_expr[g, meta$TissueSimple == t]))
    sd(tissue_means) / mean(tissue_means)
  })
  cat(sprintf("Housekeeping genes evaluated: %d, mean cross-tissue CV: %.3f\n",
              length(hk_genes), mean(hk_cv)))
}

# ============================================================================
# 13. Save
# ============================================================================
cat("\n===== Step 13: Save =====\n")
write.csv(unified_corrected, file.path(outdir, "unified_expression_matrix.csv"))
write.csv(meta, file.path(outdir, "unified_metadata.csv"), row.names = FALSE)
saveRDS(list(expr = unified_corrected, meta = meta, common_genes = common,
             pca_var = pca_var, batch_r2 = batch_r2, diag_r2 = diag_r2, tissue_r2 = tissue_r2,
             hk_genes = hk_genes, hk_cv = if (exists("hk_cv")) hk_cv else NULL),
        file.path(outdir, "module1_results.rds"))

# Summary
sink(file.path(outdir, "module1_summary.txt"))
cat(sprintf("Module 1 (FIXED): 5-Dataset Integration\nDate: %s\n\n", Sys.Date()))
cat(sprintf("Datasets integrated: GSE18123, GSE123302, GSE148450, GSE38322, GSE28521\n"))
cat(sprintf("Unified matrix: %d genes x %d samples\n", nrow(unified_corrected), ncol(unified_corrected)))
cat(sprintf("Common genes (before filter): %d\n", length(common)))
cat("\n=== Sample Distribution ===\n")
cat("Tissue x Diagnosis:\n")
print(table(meta$TissueSimple, meta$Diagnosis))
cat("\nDataset x TissueSimple:\n")
print(table(meta$Dataset, meta$TissueSimple))
cat(sprintf("\nBlood samples: %d, Brain samples: %d\n",
            sum(meta$TissueSimple != "Brain"), sum(meta$TissueSimple == "Brain")))
cat("\n=== Study Design Constraint ===\n")
cat("Tissue and Platform are perfectly confounded:\n")
cat("  GSE18123 = Peripheral_Blood + GPL570\n")
cat("  GSE123302 = Cord_Blood + GPL16686\n")
cat("  GSE148450 = Maternal_Blood + GPL25483\n")
cat("  GSE38322 = Brain + GPL10558\n")
cat("  GSE28521 = Brain + GPL6883\n")
cat("Cross-tissue inferences are constrained by this design.\n")
cat("\n=== PCA Variance Partitioning (Top 10 PCs) ===\n")
cat(sprintf("Cumulative Batch R² = %.3f\n", sum(batch_r2[1:10])))
cat(sprintf("Cumulative Diagnosis R² = %.3f\n", sum(diag_r2[1:10])))
cat(sprintf("Cumulative Tissue R² = %.3f\n", sum(tissue_r2[1:10])))
if (exists("hk_cv")) {
  cat(sprintf("\nHousekeeping gene cross-tissue CV: %.3f\n", mean(hk_cv)))
}
sink()

cat(sprintf("\n===== Module 1 (FIXED) DONE: %d genes x %d samples =====\n",
            nrow(unified_corrected), ncol(unified_corrected)))
